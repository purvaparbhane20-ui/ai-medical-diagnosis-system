# AI Medical Diagnosis System (Rule-Based Expert System)
### Using Forward and Backward Chaining

**Savitribai Phule Pune University (SPPU) | Dr. D. Y. Patil Technical Campus**  
**Internship Organization:** Codec Technologies India, Powai, Mumbai  
**Student:** Tanvi Sagar Unde (Class: TE-A, Roll No/Seat No: 32170)  
**Internal Guide:** Prof. Vinay Hiwanj  
**Industry Mentors:** Ms. Vaishali Shrivastava & Dr. Anurag Shrivastava  

---

## 📌 Project Summary
This project is an explainable, beginner-friendly **Rule-Based Expert System for Medical Diagnosis** built in Python. Unlike opaque black-box deep learning models, this system provides 100% deterministic, fully auditable clinical reasoning through:

1. **Forward Chaining (Data-Driven / Bottom-Up):**  
   Takes reported symptoms, fires matching rules in the Knowledge Base, deduces intermediate facts, and arrives at confirmed disease diagnoses along with partial match scores.
2. **Backward Chaining (Goal-Driven / Top-Down):**  
   Takes a suspected disease hypothesis, works backwards to test required conditions, and interactively queries the patient (Yes/No) to verify or refute the condition.
3. **Explanation Facility:**  
   Generates step-by-step reasoning audit trails explaining *why* a diagnosis was reached or *how* a hypothesis was verified.

---

## 🚀 How to Open and Run the Application (3 Easy Ways)

### Option 1: Standalone Web App (Zero Setup — Recommended!)
Simply **double-click** the file:
```
Medical_Diagnosis_System_App.html
```
- Opens immediately in Google Chrome, Microsoft Edge, or Firefox.
- **No Python or server required!**
- Contains the full interactive UI: quick presets (COVID-19, Malaria, Cold, Allergy), symptom checkboxes, forward chaining with match bars, interactive Yes/No backward chaining question modal, and reasoning traces.

### Option 2: One-Click Flask Server Launcher
Simply **double-click** the file:
```
Run_App.bat
```
- Starts the Python Flask server and **automatically opens your web browser** to `http://127.0.0.1:5000`.

### Option 3: Native Desktop Windows GUI (Tkinter)
Simply run:
```bash
python gui_app.py
```
- Opens a native desktop window with tabs for Forward Chaining, Backward Chaining, and Knowledge Base Explorer with popup dialogs.

### Option 4: Interactive Terminal CLI
```bash
python cli_diagnosis.py
```
- Runs in your terminal with a clean, numbered menu system.

---

## 📊 Presentation Files

| File | Description |
|:---|:---|
| [`Medical_Diagnosis_System_Presentation.pptx`](file:///c:/Users/userp/OneDrive/Desktop/AI%20Mini%20Project/Medical_Diagnosis_System_Presentation.pptx) | **Native Microsoft PowerPoint Presentation** (.pptx) with 14 slides, widescreen 16:9 layout, cards, and comparison tables. |
| [`presentation.html`](file:///c:/Users/userp/OneDrive/Desktop/AI%20Mini%20Project/presentation.html) | **Interactive Browser Slide Deck** with keyboard navigation (Left/Right arrows, Space, 'F' for Fullscreen). |
| [`PRESENTATION_SLIDES.md`](file:///c:/Users/userp/OneDrive/Desktop/AI%20Mini%20Project/PRESENTATION_SLIDES.md) | Slide transcript with detailed **speaker notes for your college viva/presentation**. |

---

## 📄 Academic Project Report

| File | Description |
|:---|:---|
| [`Medical_Diagnosis_System_Report.docx`](file:///c:/Users/userp/OneDrive/Desktop/AI%20Mini%20Project/Medical_Diagnosis_System_Report.docx) | **Official Microsoft Word Report** adhering strictly to the Savitribai Phule Pune University and Dr. D. Y. Patil Technical Campus template with all required sections, signature blocks, tables, and embedded high-resolution figures. |
| [`PROJECT_REPORT.md`](file:///c:/Users/userp/OneDrive/Desktop/AI%20Mini%20Project/PROJECT_REPORT.md) | Complete report in Markdown format for direct viewing on GitHub or VS Code. |

---

## 🗂 Complete Workspace Structure
```
AI Mini Project/
├── Medical_Diagnosis_System_App.html           # Standalone instant interactive web app (double-click to open!)
├── Run_App.bat                                 # 1-click batch launcher for Flask + browser
├── gui_app.py                                  # Native Windows Tkinter Desktop GUI
├── app.py                                      # Flask web application (with auto-browser launch)
├── cli_diagnosis.py                            # Interactive terminal CLI
├── knowledge_base.py                           # 24 symptoms, 12 diseases, 12 production rules
├── inference_engine.py                         # Pure Forward Chaining & Backward Chaining algorithms
├── test_expert_system.py                       # Automated unit tests (5/5 passed)
├── Medical_Diagnosis_System_Presentation.pptx  # Microsoft PowerPoint (.pptx) presentation
├── presentation.html                           # Browser slide deck
├── PRESENTATION_SLIDES.md                      # Slide transcript & viva speaker notes
├── Medical_Diagnosis_System_Report.docx        # Official Word Report adhering to SPPU template
├── PROJECT_REPORT.md                           # Markdown version of official report
├── generate_presentation_pptx.py               # Python generator for .pptx presentation
├── generate_report_docx.py                     # Python generator for .docx report
├── generate_diagrams.py                        # Generates high-res architecture & flowchart images
├── diagrams/                                   # High-resolution architectural figures
│   ├── flowchart_chaining.png
│   ├── system_architecture.png
│   └── disease_rules_chart.png
├── templates/
│   └── index.html                              # Flask server template
└── static/
    ├── style.css                               # Healthcare UI styling
    └── script.js                               # Frontend API logic
```
