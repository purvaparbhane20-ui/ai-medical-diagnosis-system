"""
Desktop GUI for Medical Diagnosis Expert System
===============================================
A native Windows desktop application built with Python Tkinter.
Runs completely offline with zero web server requirements!
"""

import tkinter as tk
from tkinter import ttk, messagebox, scrolledtext
from knowledge_base import SYMPTOMS, DISEASES, RULES
from inference_engine import ForwardChainingEngine, BackwardChainingEngine

class MedicalExpertGUI:
    def __init__(self, root):
        self.root = root
        self.root.title("AI Medical Diagnosis Expert System (Forward & Backward Chaining)")
        self.root.geometry("1050x720")
        self.root.minsize(900, 600)

        # Apply styling
        style = ttk.Style()
        style.theme_use("clam")
        
        # Engines
        self.fc_engine = ForwardChainingEngine()
        self.bc_engine = BackwardChainingEngine()

        # State for Forward Chaining
        self.symptom_vars = {}

        # Top Banner
        header_frame = tk.Frame(root, bg="#0284c7", height=70)
        header_frame.pack(fill=tk.X)
        header_frame.pack_propagate(False)

        lbl_title = tk.Label(header_frame, text="⚕ AI Medical Diagnosis System (Rule-Based Expert System)", 
                             font=("Segoe UI", 16, "bold"), fg="white", bg="#0284c7")
        lbl_title.pack(side=tk.LEFT, padx=20, pady=10)

        lbl_sub = tk.Label(header_frame, text="SPPU Third Year AI Capstone", 
                           font=("Segoe UI", 10), fg="#e0f2fe", bg="#0284c7")
        lbl_sub.pack(side=tk.RIGHT, padx=20, pady=10)

        # Main Notebook (Tabs)
        self.notebook = ttk.Notebook(root)
        self.notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)

        self.tab_fc = ttk.Frame(self.notebook)
        self.tab_bc = ttk.Frame(self.notebook)
        self.tab_kb = ttk.Frame(self.notebook)

        self.notebook.add(self.tab_fc, text="  ➔ Forward Chaining (Data-Driven)  ")
        self.notebook.add(self.tab_bc, text="  ⬅ Backward Chaining (Goal-Driven)  ")
        self.notebook.add(self.tab_kb, text="  📖 Knowledge Base Explorer  ")

        self.build_forward_tab()
        self.build_backward_tab()
        self.build_kb_tab()

    # ================= TAB 1: FORWARD CHAINING =================
    def build_forward_tab(self):
        paned = ttk.PanedWindow(self.tab_fc, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Left Frame: Symptoms selection
        left_frame = ttk.LabelFrame(paned, text=" 1. Select Patient Symptoms ", padding=10)
        paned.add(left_frame, weight=1)

        # Presets Bar
        preset_frame = tk.Frame(left_frame)
        preset_frame.pack(fill=tk.X, pady=(0, 10))

        tk.Label(preset_frame, text="Quick Presets: ", font=("Segoe UI", 9, "bold")).pack(side=tk.LEFT)
        ttk.Button(preset_frame, text="COVID-19", command=lambda: self.apply_preset("covid")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text="Malaria", command=lambda: self.apply_preset("malaria")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text="Common Cold", command=lambda: self.apply_preset("cold")).pack(side=tk.LEFT, padx=2)
        ttk.Button(preset_frame, text="Clear", command=self.clear_symptoms).pack(side=tk.LEFT, padx=2)

        # Scrollable Checkbox List
        canvas = tk.Canvas(left_frame, borderwidth=0, highlightthickness=0)
        scrollbar = ttk.Scrollbar(left_frame, orient="vertical", command=canvas.yview)
        scrollable_frame = ttk.Frame(canvas)

        scrollable_frame.bind(
            "<Configure>",
            lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
        )
        canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
        canvas.configure(yscrollcommand=scrollbar.set)

        canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)

        # Add checkboxes by category
        categories = ["General", "Respiratory", "Neurological", "Gastrointestinal", "ENT", "Sensory", "Musculoskeletal", "Dermatological"]
        for cat in categories:
            lbl_cat = tk.Label(scrollable_frame, text=f"─── {cat.upper()} SYMPTOMS ───", 
                               font=("Segoe UI", 8, "bold"), fg="#0284c7")
            lbl_cat.pack(anchor="w", pady=(8, 2))

            for key, val in SYMPTOMS.items():
                if val["category"] == cat:
                    var = tk.BooleanVar()
                    self.symptom_vars[key] = var
                    cb = ttk.Checkbutton(scrollable_frame, text=val["name"], variable=var)
                    cb.pack(anchor="w", padx=10, pady=1)

        # Diagnose Button
        btn_run = tk.Button(left_frame, text="⚡ Run Forward Chaining Diagnosis", 
                            font=("Segoe UI", 10, "bold"), bg="#0284c7", fg="white", 
                            padx=10, pady=6, command=self.run_forward_chaining)
        btn_run.pack(fill=tk.X, pady=(10, 0))

        # Right Frame: Diagnostic Results
        right_frame = ttk.LabelFrame(paned, text=" 2. Diagnostic Results & Audit Trace ", padding=10)
        paned.add(right_frame, weight=1)

        self.txt_fc_results = scrolledtext.ScrolledText(right_frame, wrap=tk.WORD, font=("Consolas", 10))
        self.txt_fc_results.pack(fill=tk.BOTH, expand=True)
        self.txt_fc_results.insert(tk.END, "Select symptoms on the left and click 'Run Forward Chaining Diagnosis' to start inference.\n")

    def apply_preset(self, p_type):
        self.clear_symptoms()
        presets = {
            "covid": ["fever", "cough", "fatigue", "loss_of_taste_smell"],
            "malaria": ["high_fever", "chills", "sweating", "headache"],
            "cold": ["cough", "sore_throat", "runny_nose", "sneezing"]
        }
        for k in presets.get(p_type, []):
            if k in self.symptom_vars:
                self.symptom_vars[k].set(True)

    def clear_symptoms(self):
        for var in self.symptom_vars.values():
            var.set(False)

    def run_forward_chaining(self):
        selected = [k for k, v in self.symptom_vars.items() if v.get()]
        if not selected:
            messagebox.showwarning("No Symptoms Selected", "Please select at least one symptom.")
            return

        res = self.fc_engine.diagnose(selected)
        self.txt_fc_results.delete(1.0, tk.END)

        self.txt_fc_results.insert(tk.END, "============================================================\n")
        self.txt_fc_results.insert(tk.END, "          FORWARD CHAINING DIAGNOSIS RESULTS                \n")
        self.txt_fc_results.insert(tk.END, "============================================================\n\n")

        if res["diagnoses"]:
            self.txt_fc_results.insert(tk.END, "★ CONFIRMED DIAGNOSES:\n")
            for d in res["diagnoses"]:
                info = DISEASES.get(d, {})
                self.txt_fc_results.insert(tk.END, f"  ► {info.get('name', d)}\n")
                self.txt_fc_results.insert(tk.END, f"    Severity: {info.get('severity', 'Unknown')}\n")
                self.txt_fc_results.insert(tk.END, f"    Specialist: {info.get('doctor', 'Physician')}\n")
                self.txt_fc_results.insert(tk.END, "    Precautions:\n")
                for p in info.get("precautions", []):
                    self.txt_fc_results.insert(tk.END, f"      • {p}\n")
                self.txt_fc_results.insert(tk.END, "\n")
        else:
            self.txt_fc_results.insert(tk.END, "No single 100% conclusive match found.\nSee differential scores below:\n\n")

        self.txt_fc_results.insert(tk.END, "--- TOP MATCHING SCORES ---\n")
        for pm in res["partial_matches"][:5]:
            status = "100% MATCH" if pm["fully_matched"] else f"{pm['match_score']}% Match"
            self.txt_fc_results.insert(tk.END, f"  • {pm['disease']}: {status}\n")

        self.txt_fc_results.insert(tk.END, "\n============================================================\n")
        self.txt_fc_results.insert(tk.END, "                REASONING EXECUTION TRACE                   \n")
        self.txt_fc_results.insert(tk.END, "============================================================\n")
        for line in res["trace"]:
            self.txt_fc_results.insert(tk.END, f"{line}\n")

    # ================= TAB 2: BACKWARD CHAINING =================
    def build_backward_tab(self):
        paned = ttk.PanedWindow(self.tab_bc, orient=tk.HORIZONTAL)
        paned.pack(fill=tk.BOTH, expand=True, padx=5, pady=5)

        # Left: Controls
        left_frame = ttk.LabelFrame(paned, text=" 1. Select Hypothesis & Verify ", padding=15)
        paned.add(left_frame, weight=1)

        tk.Label(left_frame, text="Select Disease Hypothesis to Test:", font=("Segoe UI", 10, "bold")).pack(anchor="w", pady=(0, 5))
        
        self.cb_goal = ttk.Combobox(left_frame, values=list(DISEASES.keys()), state="readonly", font=("Segoe UI", 10))
        self.cb_goal.pack(fill=tk.X, pady=(0, 15))
        self.cb_goal.set("COVID-19")

        btn_verify = tk.Button(left_frame, text="🔍 Start Interactive Verification", 
                               font=("Segoe UI", 10, "bold"), bg="#10b981", fg="white", 
                               padx=10, pady=8, command=self.run_backward_chaining)
        btn_verify.pack(fill=tk.X, pady=(0, 15))

        tk.Label(left_frame, text="How Backward Chaining Works in this System:\n\n"
                                  "1. Select a disease hypothesis above.\n"
                                  "2. Click 'Start Interactive Verification'.\n"
                                  "3. The system will ask popup questions (Yes/No)\n"
                                  "   only for conditions required to prove that disease.\n"
                                  "4. View the proof tree and trace on the right.",
                 font=("Segoe UI", 9), justify=tk.LEFT, fg="#475569").pack(anchor="w")

        # Right: Results
        right_frame = ttk.LabelFrame(paned, text=" 2. Proof Resolution Tree & Trace ", padding=10)
        paned.add(right_frame, weight=1)

        self.txt_bc_results = scrolledtext.ScrolledText(right_frame, wrap=tk.WORD, font=("Consolas", 10))
        self.txt_bc_results.pack(fill=tk.BOTH, expand=True)
        self.txt_bc_results.insert(tk.END, "Select a target hypothesis and click 'Start Interactive Verification'.\n")

    def run_backward_chaining(self):
        goal = self.cb_goal.get()
        if not goal:
            return

        def ask_patient(sym_key):
            name = SYMPTOMS.get(sym_key, {}).get("name", sym_key)
            return messagebox.askyesno("Diagnostic Question", f"Does the patient experience:\n\n'{name}'?")

        res = self.bc_engine.test_hypothesis(goal, ask_callback=ask_patient)
        self.txt_bc_results.delete(1.0, tk.END)

        self.txt_bc_results.insert(tk.END, "============================================================\n")
        self.txt_bc_results.insert(tk.END, f"        BACKWARD CHAINING VERIFICATION: {goal}              \n")
        self.txt_bc_results.insert(tk.END, "============================================================\n\n")

        if res["result"]:
            self.txt_bc_results.insert(tk.END, f"✓ HYPOTHESIS CONFIRMED: Patient has {goal}!\n\n")
            d = DISEASES[goal]
            self.txt_bc_results.insert(tk.END, f"Severity: {d['severity']}\n")
            self.txt_bc_results.insert(tk.END, f"Specialist: {d['doctor']}\n")
            self.txt_bc_results.insert(tk.END, "Recommended Precautions:\n")
            for p in d["precautions"]:
                self.txt_bc_results.insert(tk.END, f"  • {p}\n")
        else:
            self.txt_bc_results.insert(tk.END, f"✗ HYPOTHESIS REFUTED: Conditions for {goal} were NOT satisfied.\n\n")
            if res["missing_symptoms"]:
                names = [SYMPTOMS.get(m, {}).get("name", m) for m in res["missing_symptoms"]]
                self.txt_bc_results.insert(tk.END, f"Unsatisfied conditions: {', '.join(names)}\n")

        self.txt_bc_results.insert(tk.END, "\n============================================================\n")
        self.txt_bc_results.insert(tk.END, "                GOAL RESOLUTION TRACE                       \n")
        self.txt_bc_results.insert(tk.END, "============================================================\n")
        for line in res["trace"]:
            self.txt_bc_results.insert(tk.END, f"{line}\n")

    # ================= TAB 3: KNOWLEDGE BASE =================
    def build_kb_tab(self):
        txt_kb = scrolledtext.ScrolledText(self.tab_kb, wrap=tk.WORD, font=("Consolas", 10), padding=10)
        txt_kb.pack(fill=tk.BOTH, expand=True)

        txt_kb.insert(tk.END, "============================================================\n")
        txt_kb.insert(tk.END, "         KNOWLEDGE BASE: PRODUCTION RULES (IF-THEN)         \n")
        txt_kb.insert(tk.END, "============================================================\n\n")

        for r in RULES:
            txt_kb.insert(tk.END, f"[{r['id']}] ({r['rule_type'].upper()})\n")
            txt_kb.insert(tk.END, f"  Description: {r['description']}\n")
            txt_kb.insert(tk.END, f"  IF Conditions: {r['if_conditions']}\n")
            txt_kb.insert(tk.END, f"  THEN Conclusion: {r['then_conclusion']}\n\n")

        txt_kb.insert(tk.END, "============================================================\n")
        txt_kb.insert(tk.END, "                TARGET DISEASE DIRECTORY                    \n")
        txt_kb.insert(tk.END, "============================================================\n\n")

        for d, info in DISEASES.items():
            txt_kb.insert(tk.END, f"• {d} [{info['severity']}]\n")
            txt_kb.insert(tk.END, f"  Specialist: {info['doctor']}\n")
            txt_kb.insert(tk.END, f"  Description: {info['description']}\n\n")

def main():
    root = tk.Tk()
    app = MedicalExpertGUI(root)
    root.mainloop()

if __name__ == "__main__":
    main()
