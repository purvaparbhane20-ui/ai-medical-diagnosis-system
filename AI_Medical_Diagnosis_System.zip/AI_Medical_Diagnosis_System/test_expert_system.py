"""
Unit Tests for Medical Diagnosis Expert System
==============================================
Validates:
1. Forward Chaining diagnoses for classic disease symptoms.
2. Intermediate fact derivation (e.g. severe systemic infection).
3. Partial match scores.
4. Backward Chaining goal-driven hypothesis testing with known facts and mock questions.
"""

from knowledge_base import RULES, DISEASES, SYMPTOMS
from inference_engine import ForwardChainingEngine, BackwardChainingEngine


def test_forward_chaining_covid():
    print("\n--- Testing Forward Chaining: COVID-19 ---")
    engine = ForwardChainingEngine()
    symptoms = ["fever", "cough", "fatigue", "loss_of_taste_smell"]
    res = engine.diagnose(symptoms)
    
    print(f"Initial Symptoms: {symptoms}")
    print(f"Confirmed Diagnoses: {res['diagnoses']}")
    assert "COVID-19" in res["diagnoses"], "COVID-19 should be diagnosed"
    print("Test Passed: COVID-19 successfully diagnosed via Forward Chaining.")


def test_forward_chaining_malaria():
    print("\n--- Testing Forward Chaining: Malaria ---")
    engine = ForwardChainingEngine()
    symptoms = ["high_fever", "chills", "sweating", "headache"]
    res = engine.diagnose(symptoms)
    
    print(f"Initial Symptoms: {symptoms}")
    print(f"Confirmed Diagnoses: {res['diagnoses']}")
    print(f"Derived Facts: {res['derived_facts']}")
    assert "Malaria" in res["diagnoses"], "Malaria should be diagnosed"
    # Intermediate rule R_INT_01 should also have fired: high_fever + chills -> severe_systemic_infection
    assert "severe_systemic_infection" in res["derived_facts"], "Intermediate fact should be derived"
    print("Test Passed: Malaria and intermediate fact successfully derived.")


def test_backward_chaining_success():
    print("\n--- Testing Backward Chaining: Common Cold (Success) ---")
    engine = BackwardChainingEngine()
    known = {"cough": True, "sore_throat": True, "runny_nose": True, "sneezing": True}
    res = engine.test_hypothesis("Common Cold", known_facts=known)
    
    print(f"Hypothesis: Common Cold")
    print(f"Result: {res['result']}")
    assert res["result"] is True, "Common Cold hypothesis should succeed"
    print("Test Passed: Common Cold hypothesis proven true.")


def test_backward_chaining_interactive():
    print("\n--- Testing Backward Chaining: Interactive Questioning ---")
    engine = BackwardChainingEngine()
    
    # Mock user answering Yes to Strep Throat symptoms, No to others
    user_answers = {
        "sore_throat": True,
        "fever": True,
        "swollen_tonsils": True
    }
    
    def mock_ask(symptom):
        ans = user_answers.get(symptom, False)
        print(f"  [Mock Ask] Patient asked about '{symptom}' -> answered {ans}")
        return ans

    res = engine.test_hypothesis("Strep Throat", ask_callback=mock_ask)
    print(f"Hypothesis: Strep Throat")
    print(f"Result: {res['result']}")
    assert res["result"] is True, "Strep Throat hypothesis should be proven interactively"
    print("Test Passed: Strep Throat hypothesis proven via interactive questioning.")


def test_backward_chaining_failure():
    print("\n--- Testing Backward Chaining: Migraine (Refuted) ---")
    engine = BackwardChainingEngine()
    known = {"severe_headache": True, "nausea": False, "sensitivity_to_light": True}
    res = engine.test_hypothesis("Migraine", known_facts=known)
    
    print(f"Hypothesis: Migraine")
    print(f"Result: {res['result']}")
    assert res["result"] is False, "Migraine hypothesis should be refuted due to missing nausea"
    print("Test Passed: Migraine hypothesis correctly refuted.")


if __name__ == "__main__":
    test_forward_chaining_covid()
    test_forward_chaining_malaria()
    test_backward_chaining_success()
    test_backward_chaining_interactive()
    test_backward_chaining_failure()
    print("\n==========================================")
    print("All Unit Tests Passed Successfully! (5/5)")
    print("==========================================")
