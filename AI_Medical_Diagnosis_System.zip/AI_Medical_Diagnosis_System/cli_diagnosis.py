"""
Medical Diagnosis Expert System - Command Line Interface (CLI)
==============================================================
A beginner-friendly, interactive terminal tool demonstrating:
- Forward Chaining (Data-Driven Diagnosis)
- Backward Chaining (Goal-Driven Hypothesis Testing)
- Rule Base & Symptom Explorer
- Detailed Reasoning Traces and Explanations
"""

import sys
from knowledge_base import SYMPTOMS, DISEASES, RULES
from inference_engine import ForwardChainingEngine, BackwardChainingEngine


def print_banner():
    print("=" * 70)
    print("        AI MEDICAL DIAGNOSIS SYSTEM (RULE-BASED EXPERT SYSTEM)        ")
    print("          Featuring Forward Chaining & Backward Chaining              ")
    print("=" * 70)


def display_main_menu():
    print("\n[MAIN MENU]")
    print("1. Diagnose Symptoms (Forward Chaining - Data Driven)")
    print("2. Test a Disease Hypothesis (Backward Chaining - Goal Driven)")
    print("3. View Knowledge Base Rules & Target Diseases")
    print("4. Quick Demo Run (Simulate Classic Case)")
    print("5. Exit System")
    print("-" * 70)


def forward_chaining_interactive():
    print("\n" + "=" * 60)
    print(" MODE 1: FORWARD CHAINING DIAGNOSIS (DATA-DRIVEN)")
    print("=" * 60)
    print("Select all symptoms the patient is experiencing:")

    symptom_keys = list(SYMPTOMS.keys())
    for idx, key in enumerate(symptom_keys, 1):
        info = SYMPTOMS[key]
        print(f"  {idx:2d}. {info['name']} [{info['category']}]")

    print("\nEnter symptom numbers separated by commas (e.g. 1, 7, 4, 14):")
    choice = input("> ").strip()

    if not choice:
        print("No symptoms entered. Returning to menu.")
        return

    selected_symptoms = []
    try:
        indices = [int(x.strip()) for x in choice.split(",") if x.strip().isdigit()]
        for i in indices:
            if 1 <= i <= len(symptom_keys):
                selected_symptoms.append(symptom_keys[i - 1])
    except Exception as e:
        print(f"Invalid input: {e}")
        return

    if not selected_symptoms:
        print("No valid symptoms selected.")
        return

    print(f"\n[INFO] Selected Symptoms ({len(selected_symptoms)}):")
    for s in selected_symptoms:
        print(f"  • {SYMPTOMS[s]['name']}")

    engine = ForwardChainingEngine()
    result = engine.diagnose(selected_symptoms)

    print("\n" + "-" * 60)
    print("DIAGNOSIS RESULTS (FORWARD CHAINING)")
    print("-" * 60)

    if result["diagnoses"]:
        print("\n★ CONFIRMED DIAGNOSIS:")
        for diag in result["diagnoses"]:
            d_info = DISEASES.get(diag, {})
            print(f"\n  ► Disease: {diag}")
            print(f"    Severity: {d_info.get('severity', 'Unknown')}")
            print(f"    Description: {d_info.get('description', '')}")
            print(f"    Consult Specialist: {d_info.get('doctor', 'Physician')}")
            print("    Recommended Precautions:")
            for p in d_info.get("precautions", []):
                print(f"      - {p}")
    else:
        print("\nNo definitive 100% rule match found for this exact symptom profile.")

    print("\n[PARTIAL MATCHES & DIFFERENTIAL SCORES]")
    for pm in result["partial_matches"][:5]:
        status = "COMPLETE MATCH" if pm["fully_matched"] else f"{pm['match_score']}% Match"
        print(f"  • {pm['disease']}: {status}")
        if pm["missing_symptoms"]:
            missing_names = [SYMPTOMS.get(m, {}).get("name", m) for m in pm["missing_symptoms"]]
            print(f"    Missing to confirm: {', '.join(missing_names)}")

    print("\nWould you like to view the step-by-step reasoning trace? (y/n):")
    if input("> ").strip().lower() == "y":
        print("\n--- REASONING AUDIT TRACE ---")
        for line in result["trace"]:
            print(line)


def backward_chaining_interactive():
    print("\n" + "=" * 60)
    print(" MODE 2: BACKWARD CHAINING HYPOTHESIS TESTING (GOAL-DRIVEN)")
    print("=" * 60)
    print("Select a disease hypothesis to test:")

    disease_keys = list(DISEASES.keys())
    for idx, key in enumerate(disease_keys, 1):
        print(f"  {idx:2d}. {key} ({DISEASES[key]['severity']})")

    choice = input("\nEnter disease number: ").strip()
    if not choice.isdigit() or not (1 <= int(choice) <= len(disease_keys)):
        print("Invalid selection. Returning to menu.")
        return

    target_disease = disease_keys[int(choice) - 1]
    print(f"\nTarget Hypothesis Selected: '{target_disease}'")
    print("The system will now ask diagnostic questions to verify this hypothesis.\n")

    def ask_user(symptom_key):
        sym_name = SYMPTOMS.get(symptom_key, {}).get("name", symptom_key)
        while True:
            ans = input(f"Does the patient have '{sym_name}'? (y/n): ").strip().lower()
            if ans in ["y", "yes"]:
                return True
            elif ans in ["n", "no"]:
                return False
            print("Please type 'y' for Yes or 'n' for No.")

    engine = BackwardChainingEngine()
    result = engine.test_hypothesis(target_disease, ask_callback=ask_user)

    print("\n" + "-" * 60)
    print(f"HYPOTHESIS VERIFICATION RESULT FOR: {target_disease}")
    print("-" * 60)

    if result["result"]:
        print(f"\n✓ CONFIRMED: The patient's symptoms verify the diagnosis of {target_disease}!")
        d_info = DISEASES[target_disease]
        print(f"Severity: {d_info['severity']}")
        print(f"Consult Specialist: {d_info['doctor']}")
        print("Recommended Precautions:")
        for p in d_info["precautions"]:
            print(f"  - {p}")
    else:
        print(f"\n✗ REFUTED: The hypothesis of {target_disease} could NOT be verified.")
        if result["missing_symptoms"]:
            missing_names = [SYMPTOMS.get(m, {}).get("name", m) for m in result["missing_symptoms"]]
            print(f"Unsatisfied or negative conditions: {', '.join(missing_names)}")

    print("\nWould you like to view the goal-resolution trace? (y/n):")
    if input("> ").strip().lower() == "y":
        print("\n--- GOAL RESOLUTION TRACE ---")
        for line in result["trace"]:
            print(line)


def view_knowledge_base():
    print("\n" + "=" * 60)
    print(" KNOWLEDGE BASE: RULES & TARGET DISEASES")
    print("=" * 60)
    print(f"Total Rules: {len(RULES)}")
    print(f"Total Diseases: {len(DISEASES)}")
    print(f"Total Symptoms: {len(SYMPTOMS)}")
    print("\n[PRODUCTION RULES]")
    for r in RULES:
        print(f"  [{r['id']}] {r['description']}")
    print("\n[TARGET DISEASES]")
    for d, info in DISEASES.items():
        print(f"  • {d} ({info['severity']}) - {info['doctor']}")


def quick_demo():
    print("\n" + "=" * 60)
    print(" QUICK DEMO: SIMULATING A PATIENT WITH MALARIA")
    print("=" * 60)
    print("1. FORWARD CHAINING RUN:")
    test_symptoms = ["high_fever", "chills", "sweating", "headache"]
    print(f"Patient reports symptoms: {test_symptoms}")
    fc_engine = ForwardChainingEngine()
    fc_res = fc_engine.diagnose(test_symptoms)
    print(f"Resulting Diagnoses: {fc_res['diagnoses']}")
    print(f"Derived Facts in Working Memory: {fc_res['derived_facts']}")
    print(f"Rules Fired: {[r['id'] for r in fc_res['fired_rules']]}")

    print("\n2. BACKWARD CHAINING RUN:")
    print("Testing Goal: 'Malaria' with pre-stored known facts...")
    bc_engine = BackwardChainingEngine()
    bc_res = bc_engine.test_hypothesis("Malaria", known_facts=set(test_symptoms))
    print(f"Hypothesis Verification: {bc_res['result']} (Confirmed)")
    print("Quick demo completed successfully!")


def main():
    print_banner()
    while True:
        display_main_menu()
        choice = input("Enter choice (1-5): ").strip()
        if choice == "1":
            forward_chaining_interactive()
        elif choice == "2":
            backward_chaining_interactive()
        elif choice == "3":
            view_knowledge_base()
        elif choice == "4":
            quick_demo()
        elif choice == "5":
            print("\nThank you for using the AI Medical Diagnosis System. Goodbye!")
            sys.exit(0)
        else:
            print("Invalid option. Please choose between 1 and 5.")


if __name__ == "__main__":
    main()
