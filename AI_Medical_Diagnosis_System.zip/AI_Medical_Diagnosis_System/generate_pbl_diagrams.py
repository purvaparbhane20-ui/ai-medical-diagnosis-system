"""
Generate dedicated diagrams for the PBL Report template:
Figure 1: Layered architecture of the AI Medical Diagnosis System
Figure 2: Knowledge Base & Working Memory Container Layout
Figure 3: Flowchart of Forward Chaining
Figure 4: Flowchart of Backward Chaining
Figure 5: Screenshot/Mockup of Forward Diagnosis Interface
Figure 6: Screenshot/Mockup of Backward Hypothesis Verification Interface
"""

import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches

os.makedirs("diagrams", exist_ok=True)

# Set non-interactive backend
plt.switch_backend("Agg")

def gen_fig1_architecture():
    fig, ax = plt.subplots(figsize=(10, 6.5), dpi=300)
    ax.axis('off')
    ax.set_title("Figure 1: Layered Architecture of the AI Medical Diagnosis System", fontsize=13, fontweight='bold', pad=15)

    layers = [
        ("PRESENTATION LAYER (gui_app.py / web / HTML5 App)\n\n"
         "Dashboard | Symptom Selector | Backward Hypothesis Verifier | Rule Explorer\n"
         "Modern healthcare responsive theme, symptom checkboxes, interactive Yes/No modals", 0.78, "#e0f2fe", "#0284c7"),
        ("INFERENCE ENGINE LAYER (inference_engine.py)\n\n"
         "Forward Chaining Engine (Data-driven Modus Ponens cycle, multi-step derivation)\n"
         "Backward Chaining Engine (Recursive sub-goal resolution with patient callback)\n"
         "Differential Scoring Engine & Conflict Resolution Strategy", 0.48, "#fef3c7", "#d97706"),
        ("KNOWLEDGE & FACT BASE LAYER (knowledge_base.py & Memory)\n\n"
         "Knowledge Base: 12 Production Rules (IF-THEN) & 12 Target Pathologies\n"
         "Working Memory: Dynamic Fact Blackboard (Known Symptoms & Inferred States)\n"
         "Explanation Facility: Human-Readable Step-by-Step Audit Reasoning Traces", 0.18, "#dcfce7", "#16a34a")
    ]

    for text, y, bg, border in layers:
        bbox = dict(boxstyle="round,pad=0.8", facecolor=bg, edgecolor=border, linewidth=2)
        ax.text(0.5, y, text, ha="center", va="center", fontsize=9.5, fontweight="600", bbox=bbox)

    # Connecting arrows
    ax.annotate('', xy=(0.5, 0.61), xytext=(0.5, 0.67),
                arrowprops=dict(facecolor='#0284c7', edgecolor='#0284c7', width=2, headwidth=7))
    ax.annotate('', xy=(0.5, 0.31), xytext=(0.5, 0.37),
                arrowprops=dict(facecolor='#d97706', edgecolor='#d97706', width=2, headwidth=7))

    plt.tight_layout()
    plt.savefig("diagrams/pbl_fig1_architecture.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/pbl_fig1_architecture.png")

def gen_fig2_kb_layout():
    fig, ax = plt.subplots(figsize=(11, 4), dpi=300)
    ax.axis('off')
    ax.set_title("Figure 2: Layout of the Rule-Based Knowledge Representation Schema", fontsize=12, fontweight='bold', pad=15)

    # Box blocks representing rule components
    blocks = [
        ("RULE_ID\n(e.g., 'R_COVID')", 0.10, 0.5, 0.16, 0.45, "#e0f2fe", "#0284c7"),
        ("ANTECEDENTS (IF)\n[fever, cough, fatigue,\nloss_of_taste_smell]", 0.34, 0.5, 0.28, 0.45, "#fef3c7", "#d97706"),
        ("CONSEQUENT (THEN)\n'COVID-19'", 0.62, 0.5, 0.22, 0.45, "#dcfce7", "#16a34a"),
        ("METADATA & PRECAUTIONS\nSeverity: Mod to Severe\nDoctor: Pulmonologist", 0.86, 0.5, 0.22, 0.45, "#ede9fe", "#7c3aed")
    ]

    for label, x, y, w, h, bg, border in blocks:
        rect = patches.FancyBboxPatch((x - w/2, y - h/2), w, h, boxstyle="round,pad=0.03", facecolor=bg, edgecolor=border, linewidth=2)
        ax.add_patch(rect)
        ax.text(x, y, label, ha="center", va="center", fontsize=8.5, fontweight="600")

    # Arrows between blocks
    ax.annotate('', xy=(0.20, 0.5), xytext=(0.18, 0.5),
                arrowprops=dict(facecolor='#0284c7', edgecolor='#0284c7', width=1.5, headwidth=6))
    ax.annotate('', xy=(0.51, 0.5), xytext=(0.48, 0.5),
                arrowprops=dict(facecolor='#d97706', edgecolor='#d97706', width=1.5, headwidth=6))
    ax.annotate('', xy=(0.75, 0.5), xytext=(0.73, 0.5),
                arrowprops=dict(facecolor='#16a34a', edgecolor='#16a34a', width=1.5, headwidth=6))

    plt.tight_layout()
    plt.savefig("diagrams/pbl_fig2_kb_layout.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/pbl_fig2_kb_layout.png")

def gen_fig3_forward_flow():
    fig, ax = plt.subplots(figsize=(7, 9), dpi=300)
    ax.axis('off')
    ax.set_title("Figure 3: Flowchart of Forward Chaining (Data-Driven Inference)", fontsize=11, fontweight='bold', pad=15)

    steps = [
        ("Start: Patient inputs reported symptoms\n(e.g., fever, cough, fatigue)", 0.92, "#f8fafc", "#64748b"),
        ("Initialize Working Memory with input symptoms", 0.77, "#e0f2fe", "#0284c7"),
        ("Scan Knowledge Base for un-fired rules\nwhose IF conditions are in Working Memory", 0.62, "#fef3c7", "#d97706"),
        ("Rule Condition Check:\nAre ALL antecedents satisfied?", 0.47, "#ede9fe", "#7c3aed"),
        ("FIRE Rule: Assert THEN consequent into Working Memory\n(Intermediate facts or Disease diagnosis)", 0.32, "#dcfce7", "#16a34a"),
        ("Generate Output:\nConfirmed Diagnoses + Differential Scores + Trace Log", 0.17, "#e0f2fe", "#0284c7"),
        ("End: Consultation Complete", 0.04, "#f8fafc", "#64748b")
    ]

    for label, y, bg, border in steps:
        bbox = dict(boxstyle="round,pad=0.5", facecolor=bg, edgecolor=border, linewidth=1.5)
        ax.text(0.5, y, label, ha="center", va="center", fontsize=8.5, fontweight="600", bbox=bbox)

    for y_s, y_e in [(0.87, 0.81), (0.72, 0.66), (0.57, 0.52), (0.42, 0.37), (0.27, 0.22), (0.12, 0.07)]:
        ax.annotate('', xy=(0.5, y_e), xytext=(0.5, y_s),
                    arrowprops=dict(facecolor='#0284c7', edgecolor='#0284c7', width=1.5, headwidth=6))

    plt.tight_layout()
    plt.savefig("diagrams/pbl_fig3_forward_flow.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/pbl_fig3_forward_flow.png")

def gen_fig4_backward_flow():
    fig, ax = plt.subplots(figsize=(7, 9), dpi=300)
    ax.axis('off')
    ax.set_title("Figure 4: Flowchart of Backward Chaining and Interactive Hypothesis Testing", fontsize=11, fontweight='bold', pad=15)

    steps = [
        ("Start: Select disease hypothesis (Goal)\n(e.g., 'Malaria')", 0.92, "#f8fafc", "#64748b"),
        ("Locate candidate rules concluding the Goal\n(THEN = 'Malaria')", 0.77, "#e0f2fe", "#0284c7"),
        ("Establish required antecedents as sub-goals\n(high_fever, chills, sweating, headache)", 0.62, "#fef3c7", "#d97706"),
        ("Evaluate Sub-Goals:\nAre facts in memory or derivable?", 0.47, "#ede9fe", "#7c3aed"),
        ("Interactive Patient Inquiry:\nQuery user for primitive facts (Yes/No)", 0.32, "#fef3c7", "#d97706"),
        ("Hypothesis Resolution:\nAll conditions met? -> CONFIRMED / REFUTED", 0.17, "#dcfce7", "#16a34a"),
        ("End: Output Verification Result & Proof Tree", 0.04, "#f8fafc", "#64748b")
    ]

    for label, y, bg, border in steps:
        bbox = dict(boxstyle="round,pad=0.5", facecolor=bg, edgecolor=border, linewidth=1.5)
        ax.text(0.5, y, label, ha="center", va="center", fontsize=8.5, fontweight="600", bbox=bbox)

    for y_s, y_e in [(0.87, 0.81), (0.72, 0.66), (0.57, 0.52), (0.42, 0.37), (0.27, 0.22), (0.12, 0.07)]:
        ax.annotate('', xy=(0.5, y_e), xytext=(0.5, y_s),
                    arrowprops=dict(facecolor='#0d9488', edgecolor='#0d9488', width=1.5, headwidth=6))

    plt.tight_layout()
    plt.savefig("diagrams/pbl_fig4_backward_flow.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/pbl_fig4_backward_flow.png")

def gen_fig5_fig6_ui_mockups():
    # Figure 5: Forward Diagnosis Screen Mockup
    fig, ax = plt.subplots(figsize=(10, 5.5), dpi=300)
    ax.axis('off')
    ax.set_title("Figure 5: Forward Chaining Diagnosis Page showing Confirmed Case & Match Bars", fontsize=11, fontweight='bold', pad=12)

    # Outer browser window
    rect_window = patches.FancyBboxPatch((0.02, 0.05), 0.96, 0.88, boxstyle="round,pad=0.02", facecolor="#ffffff", edgecolor="#0284c7", linewidth=2)
    ax.add_patch(rect_window)

    # Header bar
    rect_head = patches.Rectangle((0.02, 0.80), 0.96, 0.13, facecolor="#0284c7")
    ax.add_patch(rect_head)
    ax.text(0.05, 0.865, "⚕ MedExpert AI | Forward Chaining (Data-Driven Diagnosis)", color="white", fontsize=10, fontweight="bold")

    # Left panel (symptoms)
    rect_left = patches.Rectangle((0.05, 0.10), 0.42, 0.65, facecolor="#f8fafc", edgecolor="#cbd5e1", linewidth=1)
    ax.add_patch(rect_left)
    ax.text(0.07, 0.70, "Select Symptoms [Quick Presets: COVID, Malaria, Cold]", fontsize=8.5, fontweight="bold", color="#0284c7")
    ax.text(0.07, 0.63, "[X] Fever / Elevated Temperature\n[X] Dry or Productive Cough\n[X] Extreme Fatigue or Weakness\n[X] Loss of Taste or Smell (Anosmia)\n[ ] Shortness of Breath\n[ ] Severe Headache\n[ ] Chills or Shivering", fontsize=8, color="#334155")
    rect_btn = patches.FancyBboxPatch((0.07, 0.13), 0.38, 0.08, boxstyle="round,pad=0.01", facecolor="#0284c7")
    ax.add_patch(rect_btn)
    ax.text(0.26, 0.17, "⚡ RUN FORWARD DIAGNOSIS", color="white", fontsize=8.5, fontweight="bold", ha="center")

    # Right panel (results)
    rect_right = patches.Rectangle((0.51, 0.10), 0.44, 0.65, facecolor="#f8fafc", edgecolor="#cbd5e1", linewidth=1)
    ax.add_patch(rect_right)
    ax.text(0.53, 0.70, "Diagnosis Results:", fontsize=8.5, fontweight="bold", color="#16a34a")
    ax.text(0.53, 0.62, "★ Confirmed: Coronavirus Disease (COVID-19)\nSeverity: Moderate to Severe | Specialist: Pulmonologist\nPrecautions: Isolate, monitor SpO2, stay hydrated", fontsize=8, color="#0f172a")
    ax.text(0.53, 0.44, "Differential Match Scores:\n• COVID-19: 100% Match [====================]\n• Common Cold: 50% Match [==========          ]\n• Influenza: 40% Match [========              ]", fontsize=7.5, color="#475569")
    ax.text(0.53, 0.20, "Reasoning Audit Trace:\n> [INIT] Facts: ['cough', 'fatigue', 'fever', 'loss_taste_smell']\n> Cycle 1: FIRED Rule R_COVID -> Concluded COVID-19", fontsize=7, color="#0284c7", family="monospace")

    plt.tight_layout()
    plt.savefig("diagrams/pbl_fig5_forward_ui.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/pbl_fig5_forward_ui.png")

    # Figure 6: Backward Verification Screen Mockup
    fig2, ax2 = plt.subplots(figsize=(10, 5.5), dpi=300)
    ax2.axis('off')
    ax2.set_title("Figure 6: Backward Chaining Interactive Verification Page showing CONFIRMED Result", fontsize=11, fontweight='bold', pad=12)

    rect_window2 = patches.FancyBboxPatch((0.02, 0.05), 0.96, 0.88, boxstyle="round,pad=0.02", facecolor="#ffffff", edgecolor="#0d9488", linewidth=2)
    ax2.add_patch(rect_window2)

    rect_head2 = patches.Rectangle((0.02, 0.80), 0.96, 0.13, facecolor="#0d9488")
    ax2.add_patch(rect_head2)
    ax2.text(0.05, 0.865, "⚕ MedExpert AI | Backward Chaining (Hypothesis Verification)", color="white", fontsize=10, fontweight="bold")

    # Left panel (question modal)
    rect_left2 = patches.Rectangle((0.05, 0.10), 0.42, 0.65, facecolor="#f8fafc", edgecolor="#cbd5e1", linewidth=1)
    ax2.add_patch(rect_left2)
    ax2.text(0.07, 0.70, "Target Hypothesis: Malaria", fontsize=9, fontweight="bold", color="#0d9488")
    ax2.text(0.07, 0.60, "Sub-Goal Inquiry (Condition 4 of 4):\n\nDoes the patient experience:\n'Mild to Moderate Headache'?", fontsize=8.5, color="#1e293b")
    
    # Yes / No buttons
    rect_yes = patches.FancyBboxPatch((0.07, 0.35), 0.17, 0.08, boxstyle="round,pad=0.01", facecolor="#10b981")
    ax2.add_patch(rect_yes)
    ax2.text(0.155, 0.39, "✓ YES", color="white", fontsize=8.5, fontweight="bold", ha="center")
    
    rect_no = patches.FancyBboxPatch((0.27, 0.35), 0.17, 0.08, boxstyle="round,pad=0.01", facecolor="#ef4444")
    ax2.add_patch(rect_no)
    ax2.text(0.355, 0.39, "✗ NO", color="white", fontsize=8.5, fontweight="bold", ha="center")

    # Right panel (proof result)
    rect_right2 = patches.Rectangle((0.51, 0.10), 0.44, 0.65, facecolor="#f8fafc", edgecolor="#cbd5e1", linewidth=1)
    ax2.add_patch(rect_right2)
    ax2.text(0.53, 0.70, "Verification Result: PASS (CONFIRMED)", fontsize=9, fontweight="bold", color="#16a34a")
    ax2.text(0.53, 0.60, "✓ HYPOTHESIS CONFIRMED: Malaria\nAll 4 required antecedents satisfied:\n• High-Grade Fever (>102°F) -> YES\n• Chills or Shivering -> YES\n• Excessive Sweating -> YES\n• Headache -> YES", fontsize=8, color="#0f172a")
    ax2.text(0.53, 0.32, "Proof Tree Resolution:\nGoal: Malaria [TRUE]\n └── Rule R_MALARIA [SATISFIED]\n      ├── high_fever: Verified\n      ├── chills: Verified\n      ├── sweating: Verified\n      └── headache: Verified", fontsize=7.5, color="#0d9488", family="monospace")

    plt.tight_layout()
    plt.savefig("diagrams/pbl_fig6_backward_ui.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/pbl_fig6_backward_ui.png")

if __name__ == "__main__":
    gen_fig1_architecture()
    gen_fig2_kb_layout()
    gen_fig3_forward_flow()
    gen_fig4_backward_flow()
    gen_fig5_fig6_ui_mockups()
    print("All PBL diagrams generated successfully.")
