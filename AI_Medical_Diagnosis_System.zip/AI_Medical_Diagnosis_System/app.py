"""
Flask Web Application for Medical Diagnosis Expert System
=========================================================
Provides an intuitive, modern, beginner-friendly graphical web interface
for Forward Chaining and Backward Chaining inference demonstrations.

Automatically opens the user's web browser upon launch!
"""

import os
import sys
import webbrowser
import threading
from flask import Flask, render_template, request, jsonify
from knowledge_base import SYMPTOMS, DISEASES, RULES
from inference_engine import ForwardChainingEngine, BackwardChainingEngine

# Set working directory to the script's directory to avoid template not found errors
os.chdir(os.path.dirname(os.path.abspath(__file__)))

app = Flask(__name__)

# Initialize engines
forward_engine = ForwardChainingEngine()
backward_engine = BackwardChainingEngine()


@app.route("/")
def index():
    return render_template(
        "index.html",
        symptoms=SYMPTOMS,
        diseases=DISEASES,
        rules=RULES
    )


@app.route("/api/data", methods=["GET"])
def get_data():
    return jsonify({
        "symptoms": SYMPTOMS,
        "diseases": DISEASES,
        "rules": RULES
    })


@app.route("/api/forward_chain", methods=["POST"])
def run_forward():
    data = request.get_json() or {}
    selected_symptoms = data.get("symptoms", [])
    
    result = forward_engine.diagnose(selected_symptoms)
    
    # Enrich diagnoses with disease meta-info
    enriched_diagnoses = []
    for d_name in result["diagnoses"]:
        info = DISEASES.get(d_name, {})
        enriched_diagnoses.append({
            "name": d_name,
            "title": info.get("name", d_name),
            "severity": info.get("severity", "Unknown"),
            "description": info.get("description", ""),
            "doctor": info.get("doctor", "General Physician"),
            "precautions": info.get("precautions", [])
        })

    return jsonify({
        "status": "success",
        "diagnoses": enriched_diagnoses,
        "derived_facts": result["derived_facts"],
        "fired_rules": result["fired_rules"],
        "trace": result["trace"],
        "partial_matches": result["partial_matches"]
    })


@app.route("/api/backward_chain", methods=["POST"])
def run_backward():
    data = request.get_json() or {}
    goal = data.get("goal")
    known_answers = data.get("answers", {}) # dict of symptom_key -> boolean

    if not goal:
        return jsonify({"status": "error", "message": "Goal disease is required"}), 400

    result = backward_engine.test_hypothesis(goal, known_facts=known_answers)
    
    disease_info = DISEASES.get(goal, {})

    return jsonify({
        "status": "success",
        "goal": goal,
        "disease_info": disease_info,
        "confirmed": result["result"],
        "proof_tree": result["proof_tree"],
        "trace": result["trace"],
        "memory": result["memory"],
        "missing_symptoms": result["missing_symptoms"]
    })


def open_browser():
    try:
        webbrowser.open("http://127.0.0.1:5000")
    except Exception as e:
        print("Could not auto-launch browser:", e)


if __name__ == "__main__":
    print("=" * 70)
    print("Starting AI Medical Diagnosis System Web Application...")
    print("Opening browser automatically at: http://127.0.0.1:5000")
    print("=" * 70)
    # Start timer to open browser automatically after server boots
    threading.Timer(1.2, open_browser).start()
    app.run(host="127.0.0.1", port=5000, debug=False)
