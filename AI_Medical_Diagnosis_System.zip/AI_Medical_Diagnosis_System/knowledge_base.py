"""
Knowledge Base for Medical Diagnosis Expert System
==================================================
This module defines the facts, symptoms, diseases, and production rules (IF-THEN)
used by both the Forward Chaining and Backward Chaining inference engines.

Designed for beginner-level clarity while maintaining academic rigor.
"""

# 1. DICTIONARY OF ALL RECOGNIZED SYMPTOMS
# Key: internal symbol, Value: human-readable name & category
SYMPTOMS = {
    # Systemic / General
    "fever": {"name": "Fever / Elevated Body Temperature", "category": "General"},
    "high_fever": {"name": "High-Grade Fever (> 102°F / 38.9°C)", "category": "General"},
    "chills": {"name": "Chills or Shivering", "category": "General"},
    "fatigue": {"name": "Extreme Fatigue or Weakness", "category": "General"},
    "body_ache": {"name": "Generalized Body / Muscle Aches", "category": "General"},
    "sweating": {"name": "Excessive Sweating (especially at night)", "category": "General"},
    
    # Respiratory & ENT
    "cough": {"name": "Dry or Productive Cough", "category": "Respiratory"},
    "shortness_of_breath": {"name": "Shortness of Breath / Breathing Difficulty", "category": "Respiratory"},
    "sore_throat": {"name": "Sore Throat / Painful Swallowing", "category": "Respiratory"},
    "runny_nose": {"name": "Runny or Stuffy Nose (Congestion)", "category": "Respiratory"},
    "sneezing": {"name": "Frequent Sneezing", "category": "Respiratory"},
    "chest_pain": {"name": "Chest Discomfort or Tightness", "category": "Respiratory"},
    "wheezing": {"name": "Wheezing / Whistling Breath Sound", "category": "Respiratory"},
    
    # Sensory & Neurological
    "loss_of_taste_smell": {"name": "Loss of Taste or Smell (Anosmia)", "category": "Neurological"},
    "headache": {"name": "Mild to Moderate Headache", "category": "Neurological"},
    "severe_headache": {"name": "Severe Throbbing Headache", "category": "Neurological"},
    "sensitivity_to_light": {"name": "Light / Sound Sensitivity (Photophobia)", "category": "Neurological"},
    
    # Gastrointestinal
    "nausea": {"name": "Nausea or Sick Stomach", "category": "Gastrointestinal"},
    "vomiting": {"name": "Vomiting", "category": "Gastrointestinal"},
    "abdominal_pain": {"name": "Abdominal Cramping / Stomach Pain", "category": "Gastrointestinal"},
    "diarrhea": {"name": "Watery Stools / Diarrhea", "category": "Gastrointestinal"},
    "loss_of_appetite": {"name": "Loss of Appetite", "category": "Gastrointestinal"},
    
    # Musculoskeletal & Dermatological
    "joint_pain": {"name": "Severe Joint Pain / Arthralgia", "category": "Musculoskeletal"},
    "skin_rash": {"name": "Red Spots / Skin Rash", "category": "Dermatological"},
    "swollen_tonsils": {"name": "Swollen Tonsils or White Patches on Throat", "category": "ENT"},
    "itchy_eyes": {"name": "Red, Itchy, or Watery Eyes", "category": "Sensory"}
}

# 2. PROFILES FOR ALL TARGET DISEASES / DIAGNOSES
DISEASES = {
    "COVID-19": {
        "name": "Coronavirus Disease (COVID-19)",
        "severity": "Moderate to Severe",
        "description": "An infectious respiratory disease caused by the SARS-CoV-2 virus.",
        "doctor": "General Physician / Pulmonologist",
        "precautions": [
            "Isolate at home in a well-ventilated room",
            "Monitor blood oxygen saturation (SpO2) using a pulse oximeter",
            "Stay hydrated and take doctor-prescribed antipyretics",
            "Wear a high-filtration mask (N95) around others",
            "Seek emergency care if breathing difficulty or SpO2 < 94% occurs"
        ]
    },
    "Common Cold": {
        "name": "Common Cold (Viral Upper Respiratory Infection)",
        "severity": "Mild",
        "description": "A mild viral infection affecting the upper respiratory tract (nose and throat).",
        "doctor": "General Physician",
        "precautions": [
            "Get plenty of rest and sleep",
            "Drink warm fluids (herbal teas, broths, warm water with lemon)",
            "Perform steam inhalation twice daily",
            "Use saline nasal spray for congestion relief",
            "Symptoms typically resolve within 7 to 10 days"
        ]
    },
    "Influenza (Flu)": {
        "name": "Influenza (Seasonal Flu)",
        "severity": "Moderate",
        "description": "A contagious respiratory illness caused by influenza viruses.",
        "doctor": "General Physician",
        "precautions": [
            "Rest completely to conserve immune energy",
            "Drink plenty of fluids to avoid dehydration",
            "Take acetaminophen or ibuprofen for fever and pain after consulting a physician",
            "Avoid close contact with family members to prevent viral spread",
            "Consult a doctor within 48 hours for potential antiviral medications"
        ]
    },
    "Malaria": {
        "name": "Malaria (Plasmodium Parasitic Infection)",
        "severity": "Severe",
        "description": "A mosquito-borne disease caused by Plasmodium parasites characterized by cyclical fevers.",
        "doctor": "Infectious Disease Specialist / Physician",
        "precautions": [
            "Undergo immediate blood smear (microscopy) and Rapid Diagnostic Test (RDT)",
            "Strictly take prescribed antimalarial medications (e.g., ACT regimen)",
            "Use insecticide-treated bed nets and insect repellent",
            "Stay hydrated with electrolyte solutions",
            "Do not delay treatment; complicated malaria can be life-threatening"
        ]
    },
    "Typhoid Fever": {
        "name": "Typhoid Fever (Salmonella Typhi)",
        "severity": "Severe",
        "description": "A systemic bacterial infection caused by Salmonella enterica serotype Typhi.",
        "doctor": "General Physician / Gastroenterologist",
        "precautions": [
            "Confirm diagnosis via blood culture or Widal test",
            "Complete the entire prescribed antibiotic course even if feeling better",
            "Drink boiled, filtered, or bottled water only",
            "Eat freshly cooked, warm, soft-food meals; avoid raw street foods",
            "Practice thorough hand washing with soap before eating"
        ]
    },
    "Strep Throat": {
        "name": "Streptococcal Pharyngitis (Strep Throat)",
        "severity": "Moderate",
        "description": "A bacterial throat infection caused by Streptococcus pyogenes bacteria.",
        "doctor": "ENT Specialist / Physician",
        "precautions": [
            "Undergo throat swab culture or rapid strep test",
            "Complete full course of antibiotics prescribed by physician",
            "Gargle with warm salt water 3-4 times daily",
            "Replace toothbrush after starting antibiotic therapy to prevent reinfection",
            "Suck on throat lozenges for soothing pain relief"
        ]
    },
    "Allergic Rhinitis": {
        "name": "Allergic Rhinitis (Hay Fever)",
        "severity": "Mild",
        "description": "An allergic reaction causing inflammation of the nasal membranes due to allergens like pollen or dust.",
        "doctor": "Allergist / General Physician",
        "precautions": [
            "Identify and avoid known environmental allergy triggers",
            "Keep indoor windows closed during high pollen counts",
            "Use air purifiers with HEPA filters",
            "Take doctor-recommended antihistamines or nasal corticosteroids",
            "Rinse nasal passages with isotonic saline solution"
        ]
    },
    "Dengue Fever": {
        "name": "Dengue Fever (Breakbone Fever)",
        "severity": "Severe",
        "description": "A mosquito-borne viral infection transmitted by Aedes mosquitoes, causing severe joint pain and low platelets.",
        "doctor": "Physician / Hematologist",
        "precautions": [
            "Get Complete Blood Count (CBC) tested daily to monitor platelet count",
            "Do NOT take Aspirin or Ibuprofen (they increase bleeding risk); take Paracetamol only",
            "Consume plenty of oral rehydration fluids, coconut water, and soups",
            "Watch for warning signs: persistent abdominal pain, mucosal bleeding, extreme drowsiness",
            "Hospitalization is required if platelet levels drop critically"
        ]
    },
    "Migraine": {
        "name": "Migraine Headache Disorder",
        "severity": "Moderate",
        "description": "A neurological condition causing severe, throbbing headache attacks often on one side of the head.",
        "doctor": "Neurologist / Physician",
        "precautions": [
            "Rest in a quiet, dark, noise-free room during attacks",
            "Apply cold compresses or ice packs to forehead or temples",
            "Maintain consistent sleep and hydration schedules",
            "Avoid known dietary triggers (caffeine, aged cheese, artificial sweeteners)",
            "Consult a physician for triptans or preventive migraine therapy"
        ]
    },
    "Food Poisoning": {
        "name": "Acute Gastroenteritis / Food Poisoning",
        "severity": "Moderate",
        "description": "Illness caused by consuming food or water contaminated with bacteria, viruses, or toxins.",
        "doctor": "General Physician / Gastroenterologist",
        "precautions": [
            "Drink Oral Rehydration Salts (ORS) solution continuously to replace lost electrolytes",
            "Follow the BRAT diet (Bananas, Rice, Applesauce, Toast) once vomiting subsides",
            "Avoid dairy, greasy foods, caffeine, and alcohol for several days",
            "Rest stomach for a few hours immediately following vomiting episodes",
            "Seek urgent medical help if unable to keep liquids down for 24 hours"
        ]
    },
    "Bronchitis": {
        "name": "Acute Bronchitis (Chest Cold)",
        "severity": "Moderate",
        "description": "Inflammation of the lining of your bronchial tubes, which carry air to and from your lungs.",
        "doctor": "Pulmonologist / General Physician",
        "precautions": [
            "Use a cool-mist humidifier or breathe steam from a warm shower",
            "Avoid lung irritants including tobacco smoke, dust, and air pollution",
            "Get adequate bed rest to facilitate bronchial recovery",
            "Take cough suppressants or expectorants only under doctor's guidance",
            "Consult doctor if cough lingers longer than 3 weeks"
        ]
    },
    "Pneumonia": {
        "name": "Pneumonia (Pulmonary Infection)",
        "severity": "Severe",
        "description": "Infection that inflames air sacs in one or both lungs, which may fill with fluid or pus.",
        "doctor": "Pulmonologist / Critical Care Specialist",
        "precautions": [
            "Obtain immediate chest X-ray and medical examination",
            "Start targeted antibiotics or antiviral medications promptly",
            "Closely monitor oxygen saturation and respiratory rate",
            "Rest completely in bed and maintain high fluid intake",
            "Immediate hospital admission is advised for elderly or frail patients"
        ]
    }
}

# 3. PRODUCTION RULES (IF-THEN RULES)
# Each rule has:
# - id: unique identifier
# - description: human-readable explanation
# - if_conditions: list of required antecedent facts (symptoms or intermediate facts)
# - then_conclusion: consequent fact (disease diagnosis or intermediate fact)
# - rule_type: "diagnostic" or "intermediate"

RULES = [
    # Intermediate Rules (help in multi-step chaining)
    {
        "id": "R_INT_01",
        "description": "IF high fever AND chills THEN suspect severe systemic infection",
        "if_conditions": ["high_fever", "chills"],
        "then_conclusion": "severe_systemic_infection",
        "rule_type": "intermediate"
    },
    {
        "id": "R_INT_02",
        "description": "IF cough AND chest pain THEN suspect lower respiratory tract involvement",
        "if_conditions": ["cough", "chest_pain"],
        "then_conclusion": "lower_respiratory_involvement",
        "rule_type": "intermediate"
    },
    {
        "id": "R_INT_03",
        "description": "IF sneezing AND runny nose AND itchy eyes THEN suspect allergic profile",
        "if_conditions": ["sneezing", "runny_nose", "itchy_eyes"],
        "then_conclusion": "allergic_profile",
        "rule_type": "intermediate"
    },

    # Diagnostic Rules (conclude a disease)
    {
        "id": "R_COVID",
        "description": "IF fever AND cough AND fatigue AND loss of taste/smell THEN diagnose COVID-19",
        "if_conditions": ["fever", "cough", "fatigue", "loss_of_taste_smell"],
        "then_conclusion": "COVID-19",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_COLD",
        "description": "IF cough AND sore throat AND runny nose AND sneezing THEN diagnose Common Cold",
        "if_conditions": ["cough", "sore_throat", "runny_nose", "sneezing"],
        "then_conclusion": "Common Cold",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_FLU",
        "description": "IF fever AND chills AND body ache AND fatigue AND cough THEN diagnose Influenza (Flu)",
        "if_conditions": ["fever", "chills", "body_ache", "fatigue", "cough"],
        "then_conclusion": "Influenza (Flu)",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_MALARIA",
        "description": "IF high fever AND chills AND sweating AND headache THEN diagnose Malaria",
        "if_conditions": ["high_fever", "chills", "sweating", "headache"],
        "then_conclusion": "Malaria",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_TYPHOID",
        "description": "IF high fever AND abdominal pain AND headache AND fatigue AND loss of appetite THEN diagnose Typhoid Fever",
        "if_conditions": ["high_fever", "abdominal_pain", "headache", "fatigue", "loss_of_appetite"],
        "then_conclusion": "Typhoid Fever",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_STREP",
        "description": "IF sore throat AND fever AND swollen tonsils THEN diagnose Strep Throat",
        "if_conditions": ["sore_throat", "fever", "swollen_tonsils"],
        "then_conclusion": "Strep Throat",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_ALLERGY",
        "description": "IF sneezing AND runny nose AND itchy eyes THEN diagnose Allergic Rhinitis",
        "if_conditions": ["sneezing", "runny_nose", "itchy_eyes"],
        "then_conclusion": "Allergic Rhinitis",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_DENGUE",
        "description": "IF high fever AND severe joint pain AND headache AND skin rash THEN diagnose Dengue Fever",
        "if_conditions": ["high_fever", "joint_pain", "headache", "skin_rash"],
        "then_conclusion": "Dengue Fever",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_MIGRAINE",
        "description": "IF severe headache AND nausea AND sensitivity to light THEN diagnose Migraine",
        "if_conditions": ["severe_headache", "nausea", "sensitivity_to_light"],
        "then_conclusion": "Migraine",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_FOOD_POISONING",
        "description": "IF nausea AND vomiting AND abdominal pain AND diarrhea THEN diagnose Food Poisoning",
        "if_conditions": ["nausea", "vomiting", "abdominal_pain", "diarrhea"],
        "then_conclusion": "Food Poisoning",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_BRONCHITIS",
        "description": "IF cough AND wheezing AND fatigue AND chest pain THEN diagnose Bronchitis",
        "if_conditions": ["cough", "wheezing", "fatigue", "chest_pain"],
        "then_conclusion": "Bronchitis",
        "rule_type": "diagnostic"
    },
    {
        "id": "R_PNEUMONIA",
        "description": "IF high fever AND shortness of breath AND chest pain AND cough THEN diagnose Pneumonia",
        "if_conditions": ["high_fever", "shortness_of_breath", "chest_pain", "cough"],
        "then_conclusion": "Pneumonia",
        "rule_type": "diagnostic"
    }
]
