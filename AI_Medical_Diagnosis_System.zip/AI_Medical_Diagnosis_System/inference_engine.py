"""
Inference Engine for Medical Diagnosis Expert System
===================================================
Contains two classic reasoning algorithms:
1. Forward Chaining (Data-Driven Reasoning / Bottom-Up)
2. Backward Chaining (Goal-Driven Reasoning / Top-Down)

Both algorithms include complete explanation traces showing step-by-step logic.
"""

from knowledge_base import RULES, DISEASES, SYMPTOMS


class ForwardChainingEngine:
    """
    Forward Chaining (Data-Driven Inference):
    Starts with known initial symptoms (facts) provided by the patient,
    and repeatedly applies matching IF-THEN rules to derive new facts 
    and conclude diagnoses until no more rules can fire.
    """

    def __init__(self, rules=None):
        self.rules = rules if rules is not None else RULES

    def diagnose(self, initial_facts):
        """
        Executes forward chaining given a collection of known facts (symptoms).
        
        Args:
            initial_facts (set or list): Symptoms confirmed by the user.
            
        Returns:
            dict containing:
                - 'diagnoses': list of confirmed disease names
                - 'derived_facts': all facts present at the end of execution
                - 'fired_rules': list of rule IDs and details that fired
                - 'trace': step-by-step execution log explaining the reasoning
                - 'partial_matches': rules that partially matched with percentage scores
        """
        # Working memory / fact base
        working_memory = set(initial_facts)
        fired_rules = []
        trace = []
        new_fact_added = True
        cycle = 1

        trace.append(f"[INIT] Initial working memory facts: {sorted(list(working_memory))}")

        # Continue firing rules in cycles until reaching a quiescent state (no new facts)
        while new_fact_added:
            new_fact_added = False
            trace.append(f"\n--- Forward Chaining Cycle {cycle} ---")
            
            for rule in self.rules:
                rule_id = rule["id"]
                conditions = set(rule["if_conditions"])
                conclusion = rule["then_conclusion"]

                # If rule hasn't fired yet and ALL conditions are satisfied in working memory
                if rule_id not in [r["id"] for r in fired_rules]:
                    if conditions.issubset(working_memory):
                        # Fire the rule!
                        fired_rules.append(rule)
                        trace.append(f"✓ FIRED {rule_id}: {rule['description']}")
                        trace.append(f"   Antecedents satisfied: {sorted(list(conditions))}")
                        trace.append(f"   New Fact Derived -> '{conclusion}'")

                        if conclusion not in working_memory:
                            working_memory.add(conclusion)
                            new_fact_added = True
                    else:
                        missing = conditions - working_memory
                        trace.append(f"✗ Rule {rule_id} could NOT fire. Missing: {sorted(list(missing))}")

            cycle += 1

        # Identify all diagnosed diseases
        confirmed_diagnoses = [f for f in working_memory if f in DISEASES]

        # Calculate partial matches for user guidance
        partial_matches = []
        for rule in self.rules:
            if rule["rule_type"] == "diagnostic":
                conditions = set(rule["if_conditions"])
                matched = conditions.intersection(working_memory)
                score = round((len(matched) / len(conditions)) * 100, 1)
                
                partial_matches.append({
                    "rule_id": rule["id"],
                    "disease": rule["then_conclusion"],
                    "matched_symptoms": sorted(list(matched)),
                    "missing_symptoms": sorted(list(conditions - working_memory)),
                    "match_score": score,
                    "fully_matched": conditions.issubset(working_memory)
                })

        # Sort partial matches descending by match percentage
        partial_matches.sort(key=lambda x: x["match_score"], reverse=True)

        trace.append(f"\n[CONCLUSION] Inference complete. Confirmed diagnoses: {confirmed_diagnoses}")

        return {
            "diagnoses": confirmed_diagnoses,
            "derived_facts": sorted(list(working_memory)),
            "fired_rules": fired_rules,
            "trace": trace,
            "partial_matches": partial_matches
        }


class BackwardChainingEngine:
    """
    Backward Chaining (Goal-Driven Inference):
    Starts with a target hypothesis (e.g., 'Does patient have Malaria?'),
    finds rules that conclude this hypothesis, and works backwards to verify
    if all required conditions are satisfied, asking the user questions if needed.
    """

    def __init__(self, rules=None):
        self.rules = rules if rules is not None else RULES

    def test_hypothesis(self, goal, known_facts=None, ask_callback=None):
        """
        Tests whether a hypothesis (goal) can be proven.
        
        Args:
            goal (str): The disease or target fact to prove.
            known_facts (set or dict): Facts already known to be True or False.
            ask_callback (function): Callable function ask_callback(symptom_key) 
                                     returning True/False if asked interactively.
        
        Returns:
            dict containing:
                - 'goal': target hypothesis
                - 'result': True (Confirmed) / False (Refuted)
                - 'proof_tree': structured tree of conditions and verification status
                - 'trace': step-by-step reasoning trace
                - 'missing_symptoms': list of symptoms that were missing/false
        """
        trace = []
        memory = dict() # stores fact -> True/False
        
        # Populate initial memory
        if known_facts:
            if isinstance(known_facts, dict):
                memory.update(known_facts)
            else:
                for f in known_facts:
                    memory[f] = True

        trace.append(f"[INIT] Backward Chaining initiated for Goal: '{goal}'")
        
        visited_goals = set()

        def prove(current_goal, indent=0):
            prefix = "  " * indent
            trace.append(f"{prefix}? Evaluating Sub-Goal / Condition: '{current_goal}'")

            # Case 1: Already evaluated in memory
            if current_goal in memory:
                val = memory[current_goal]
                trace.append(f"{prefix}→ Known fact in memory: '{current_goal}' = {val}")
                return val, {"name": current_goal, "type": "fact", "status": val}

            # Avoid infinite circular loops
            if current_goal in visited_goals:
                trace.append(f"{prefix}⚠ Circular dependency detected on '{current_goal}'. Fails.")
                return False, {"name": current_goal, "type": "loop", "status": False}

            visited_goals.add(current_goal)

            # Case 2: Find all rules that have this goal as conclusion
            candidate_rules = [r for r in self.rules if r["then_conclusion"] == current_goal]

            if candidate_rules:
                trace.append(f"{prefix}Found {len(candidate_rules)} candidate rule(s) concluding '{current_goal}'")
                for r in candidate_rules:
                    trace.append(f"{prefix}Testing Rule [{r['id']}]: {r['description']}")
                    rule_satisfied = True
                    sub_trees = []

                    for cond in r["if_conditions"]:
                        cond_result, sub_tree = prove(cond, indent + 1)
                        sub_trees.append(sub_tree)
                        if not cond_result:
                            rule_satisfied = False
                            trace.append(f"{prefix}Rule [{r['id']}] FAILED because condition '{cond}' was NOT met.")
                            break

                    if rule_satisfied:
                        trace.append(f"{prefix}★ Rule [{r['id']}] SUCCEEDED! Concludes '{current_goal}' is TRUE.")
                        memory[current_goal] = True
                        visited_goals.remove(current_goal)
                        return True, {
                            "name": current_goal,
                            "type": "derived_goal",
                            "status": True,
                            "rule": r["id"],
                            "children": sub_trees
                        }

                visited_goals.remove(current_goal)
                memory[current_goal] = False
                return False, {
                    "name": current_goal,
                    "type": "derived_goal",
                    "status": False,
                    "children": sub_trees if 'sub_trees' in locals() else []
                }

            # Case 3: It is a primitive symptom/fact, not derived by any rule
            if ask_callback is not None:
                # Query user interactively
                trace.append(f"{prefix}Querying user for primitive fact: '{current_goal}'...")
                user_ans = ask_callback(current_goal)
                memory[current_goal] = bool(user_ans)
                trace.append(f"{prefix}User response: '{current_goal}' = {user_ans}")
                visited_goals.remove(current_goal)
                return bool(user_ans), {
                    "name": current_goal,
                    "type": "primitive_query",
                    "status": bool(user_ans)
                }
            else:
                # If cannot ask and not known, assume False
                trace.append(f"{prefix}Primitive fact '{current_goal}' is unknown and no callback provided -> Assumed False")
                memory[current_goal] = False
                visited_goals.remove(current_goal)
                return False, {
                    "name": current_goal,
                    "type": "primitive_unknown",
                    "status": False
                }

        # Run backward proof for the goal
        success, proof_tree = prove(goal, indent=0)

        missing_symptoms = [k for k, v in memory.items() if v is False and k in SYMPTOMS]

        trace.append(f"\n[RESULT] Backward Chaining concluded. Goal '{goal}' = {success}")

        return {
            "goal": goal,
            "result": success,
            "proof_tree": proof_tree,
            "memory": memory,
            "trace": trace,
            "missing_symptoms": missing_symptoms
        }
