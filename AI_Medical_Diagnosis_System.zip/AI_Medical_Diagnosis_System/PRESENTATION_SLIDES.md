# AI MEDICAL DIAGNOSIS SYSTEM (RULE-BASED EXPERT SYSTEM)
## Project Presentation Slide Deck & Viva Presentation Notes
**Student:** Tanvi Sagar Unde (TE Computer Science, Roll No: 32170)  
**Guide:** Prof. Vinay Hiwanj  
**Institution:** Dr. D. Y. Patil Technical Campus, SPPU Pune  
**Course Code:** 310255  

---

### SLIDE 1: Title Slide
- **Title:** AI Medical Diagnosis System (Rule-Based Expert System using Forward & Backward Chaining)
- **Subtitle:** An Explainable Clinical Decision Support System Built in Python
- **Presenter:** Tanvi Sagar Unde (Third Year Computer Science, Div A, Roll No: 32170)
- **Guide:** Prof. Vinay Hiwanj (Department of Computer Engineering)
- **College:** Dr. D. Y. Patil Technical Campus, Varale, Talegaon, Savitribai Phule Pune University
- **Academic Year:** 2025–2026
> **Speaker Notes:**  
> "Respected Guide, Examiners, and Teachers, Good morning. Today, I am presenting my Third Year AI Mini Project titled 'AI Medical Diagnosis System: A Rule-Based Expert System using Forward and Backward Chaining'. In this presentation, I will walk you through how symbolic AI and rule-based inference engines provide deterministic, transparent, and explainable medical triage."

---

### SLIDE 2: Problem Statement & Clinical Motivation
- **Clinical Challenge:** High patient loads in rural and semi-urban primary healthcare centers lead to triage bottlenecks and delays in early disease detection.
- **Why AI in Healthcare?** Early detection of symptoms significantly improves prognosis in conditions like COVID-19, Malaria, and Typhoid.
- **Why Rule-Based AI over Deep Learning?**
  - **Explainability:** Deep neural networks operate as black boxes, making it impossible to justify why a specific diagnosis was given.
  - **Deterministic Trust:** Rule-based expert systems follow strict medical protocols and production rules with zero hallucination.
  - **Traceability:** Every conclusion is accompanied by a step-by-step audit trace detailing which symptoms triggered which rule.
> **Speaker Notes:**  
> "In healthcare, accuracy alone is insufficient; explainability is mandatory. A doctor or patient cannot trust a recommendation without knowing *why* it was made. Our goal was to build a system that accurately identifies conditions while providing a full reasoning trace."

---

### SLIDE 3: What is a Rule-Based Expert System?
- **Definition:** An Artificial Intelligence system that emulates the decision-making ability of a human domain expert using formal knowledge representation.
- **Three Essential Pillars:**
  1. **Knowledge Base (KB):** Static repository of medical facts, symptom taxonomies, and IF–THEN production rules:
     $$\text{IF } \text{Condition}_1 \land \text{Condition}_2 \implies \text{THEN } \text{Conclusion}$$
  2. **Working Memory (Fact Base):** Dynamic blackboard holding current known facts about the specific patient being diagnosed.
  3. **Inference Engine:** The logical reasoning brain that matches facts against rules to deduce new facts or prove target hypotheses.
> **Speaker Notes:**  
> "An expert system decouples the domain knowledge from the reasoning engine. The Knowledge Base stores clinical facts, the Working Memory stores the patient's reported symptoms, and the Inference Engine applies logical rules to bridge them."

---

### SLIDE 4: Forward Chaining (Data-Driven Reasoning)
- **Direction:** Bottom-Up (from Symptoms to Diagnoses).
- **Execution Principle:**
  1. Patient presents symptoms (e.g., `fever`, `cough`, `fatigue`, `loss_of_taste_smell`).
  2. The engine loads symptoms into Working Memory.
  3. The engine iterates over rules, matching antecedents against working memory.
  4. Matching rules fire (Modus Ponens), asserting new conclusions into working memory.
  5. The loop repeats until reaching a quiescent state (no more rules fire).
- **Clinical Application:** Ideal for routine general checkups when a patient reports a set of symptoms and wants to know what conditions they might have.
> **Speaker Notes:**  
> "Forward chaining is data-driven. Think of a detective gathering clues at a scene and putting them together to discover what happened. The patient tells us what hurts, and the system deduces all matching diseases."

---

### SLIDE 5: Backward Chaining (Goal-Driven Reasoning)
- **Direction:** Top-Down (from Disease Hypothesis to Symptoms).
- **Execution Principle:**
  1. User specifies a target disease hypothesis (e.g., *"Does the patient have Malaria?"*).
  2. Engine finds rules concluding that disease.
  3. Required conditions become sub-goals to prove.
  4. If a condition is not in working memory and cannot be inferred, the system interactively queries the patient: *"Does the patient experience Chills? (Yes/No)"*.
  5. If all antecedents evaluate to True, the hypothesis is confirmed; otherwise, it is refuted.
- **Clinical Application:** Ideal when a doctor suspects a specific critical illness and conducts targeted clinical questioning to confirm or rule it out.
> **Speaker Notes:**  
> "Backward chaining is goal-driven. Think of a specialist testing a specific suspicion. Rather than asking about 50 irrelevant symptoms, the system only asks questions directly required to verify the suspected condition."

---

### SLIDE 6: Forward vs. Backward Chaining Comparison

| Parameter | Forward Chaining | Backward Chaining |
|:---|:---|:---|
| **Approach** | Data-driven (Bottom-Up) | Goal-driven (Top-Down) |
| **Starting Point** | Known patient symptoms | Suspected disease hypothesis |
| **Search Space** | Explores all consequences | Pruned to target goal sub-tree |
| **User Interaction** | Bulk symptom selection upfront | Interactive Yes/No questions |
| **Best Scenario** | Open symptom screening / Triage | Hypothesis verification / Ruling out |

---

### SLIDE 7: Knowledge Base Architecture
- **24 Clinical Symptoms:**
  - *General:* Fever, High Fever, Chills, Fatigue, Body Ache, Sweating
  - *Respiratory:* Cough, Shortness of Breath, Sore Throat, Runny Nose, Sneezing, Chest Pain, Wheezing
  - *Sensory/Neuro:* Loss of Taste/Smell, Headache, Severe Headache, Light Sensitivity, Itchy Eyes
  - *Gastrointestinal:* Nausea, Vomiting, Abdominal Pain, Diarrhea, Loss of Appetite
- **12 Target Pathologies:** COVID-19, Common Cold, Influenza, Malaria, Typhoid, Strep Throat, Allergic Rhinitis, Dengue Fever, Migraine, Food Poisoning, Bronchitis, Pneumonia.
- **Production Rules:** Multi-step rules including intermediate inferences (e.g., `high_fever` + `chills` $\implies$ `severe_systemic_infection`).

---

### SLIDE 8: System Architecture & Technologies
- **Programming Language:** Python 3.13 (Native Python data structures, sets for $O(1)$ antecedent matching).
- **Web Backend:** Flask 3.1.2 RESTful endpoints (`/api/forward_chain`, `/api/backward_chain`).
- **Frontend Dashboard:** Semantic HTML5, CSS3 Variables, ES6 JavaScript Fetch API.
- **Dual Interface Modes:**
  1. *Command Line Interface (`cli_diagnosis.py`):* Menu-driven terminal application.
  2. *Web Application (`app.py`):* Interactive browser-based dashboard.

---

### SLIDE 9: Test Verification & Results
- **Automated Unit Testing (`test_expert_system.py`):**
  - Test 1: Forward Chaining COVID-19 positive match $\implies$ **PASSED**
  - Test 2: Forward Chaining Malaria with intermediate fact $\implies$ **PASSED**
  - Test 3: Backward Chaining Common Cold verification $\implies$ **PASSED**
  - Test 4: Backward Chaining Strep Throat interactive questions $\implies$ **PASSED**
  - Test 5: Backward Chaining Migraine negative refutation $\implies$ **PASSED**
- **Evaluation:** 100% test pass rate with deterministic reproducibility and sub-10ms inference latency.

---

### SLIDE 10: Engineering Challenges & Solutions
1. **Knowledge Acquisition Bottleneck:** Solved by structuring symptoms into modular dictionaries with clear anatomical categories.
2. **Incomplete / Partial Symptom Matching:** Strict rules fail if one minor symptom is missing. Solved by implementing a Differential Scoring Metric calculating $( \text{matched} / \text{total} ) \times 100\%$.
3. **Circular Reasoning in Recursion:** Prevented through cycle detection via a visited-goals set.

---

### SLIDE 11: Future Enhancements
- **Certainty Factors & Fuzzy Logic:** Adding fuzzy linguistic terms like *"moderate fever"* or probabilistic certainty factors (0.0 to 1.0).
- **Offline Mobile App:** Developing a Flutter mobile application for rural community health workers without internet connectivity.
- **EHR Integration:** Using FHIR (Fast Healthcare Interoperability Resources) standard APIs to import patient medical histories automatically.

---

### SLIDE 12: Conclusion & Q&A
- **Summary:** The project delivers a fully functional, explainable AI Medical Diagnosis Expert System implementing both Forward and Backward chaining from scratch.
- **Takeaway:** Demonstrates how symbolic AI provides the transparency and explainability required in healthcare.
- **Thank You!** Questions and discussion welcomed.
