"""
Generate architectural diagrams and visualization plots for the Medical Diagnosis System.
These images are embedded in the Word document report and presentation slides.
"""

import os
import matplotlib.pyplot as plt
import matplotlib.patches as patches

# Ensure diagrams directory exists
os.makedirs("diagrams", exist_ok=True)

# 1. Forward vs Backward Chaining Flowchart Diagram
def generate_chaining_diagram():
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 7), dpi=300)
    fig.suptitle("Rule-Based Inference: Forward Chaining vs Backward Chaining", fontsize=15, fontweight="bold", y=0.98)

    # AX1: Forward Chaining
    ax1.set_title("FORWARD CHAINING (Data-Driven / Bottom-Up)", fontsize=12, fontweight="bold", pad=15, color="#0284c7")
    ax1.axis('off')

    fc_boxes = [
        ("Patient Symptoms (Initial Facts)\n[e.g., Fever, Cough, Fatigue]", 0.82, "#e0f2fe", "#0284c7"),
        ("Working Memory\n(Stores active facts)", 0.62, "#f1f5f9", "#475569"),
        ("Match Antecedents in Rule Base\n(IF condition1 AND condition2 ...)", 0.42, "#fef3c7", "#d97706"),
        ("Fire Matching Rules\n(Deduce Consequents)", 0.22, "#dcfce7", "#16a34a"),
        ("Concluded Disease Diagnoses\n[e.g., COVID-19, Malaria]", 0.05, "#ede9fe", "#7c3aed")
    ]

    for text, y, facecolor, edgecolor in fc_boxes:
        bbox = dict(boxstyle="round,pad=0.6", facecolor=facecolor, edgecolor=edgecolor, linewidth=2)
        ax1.text(0.5, y, text, ha="center", va="center", fontsize=9.5, fontweight="600", bbox=bbox)

    # Downward arrows for Forward Chaining
    for y_start, y_end in [(0.75, 0.69), (0.55, 0.49), (0.35, 0.29), (0.15, 0.11)]:
        ax1.annotate('', xy=(0.5, y_end), xytext=(0.5, y_start),
                     arrowprops=dict(facecolor='#0284c7', edgecolor='#0284c7', width=2, headwidth=8))

    # AX2: Backward Chaining
    ax2.set_title("BACKWARD CHAINING (Goal-Driven / Top-Down)", fontsize=12, fontweight="bold", pad=15, color="#0d9488")
    ax2.axis('off')

    bc_boxes = [
        ("Hypothesis / Target Goal\n[e.g., Suspect Malaria?]", 0.82, "#ccfbf1", "#0d9488"),
        ("Search Rule Base for Rules\nConcluding the Goal (THEN Malaria)", 0.62, "#fef3c7", "#d97706"),
        ("Identify Required Antecedent Sub-Goals\n[High Fever, Chills, Sweating]", 0.42, "#f1f5f9", "#475569"),
        ("Interactive Patient Inquiry / Fact Check\n[Query: Does patient have Chills?]", 0.22, "#e0f2fe", "#0284c7"),
        ("Hypothesis Verified or Refuted\n[Goal = TRUE or FALSE]", 0.05, "#dcfce7", "#16a34a")
    ]

    for text, y, facecolor, edgecolor in bc_boxes:
        bbox = dict(boxstyle="round,pad=0.6", facecolor=facecolor, edgecolor=edgecolor, linewidth=2)
        ax2.text(0.5, y, text, ha="center", va="center", fontsize=9.5, fontweight="600", bbox=bbox)

    # Downward arrows for Backward Chaining
    for y_start, y_end in [(0.75, 0.69), (0.55, 0.49), (0.35, 0.29), (0.15, 0.11)]:
        ax2.annotate('', xy=(0.5, y_end), xytext=(0.5, y_start),
                     arrowprops=dict(facecolor='#0d9488', edgecolor='#0d9488', width=2, headwidth=8))

    plt.tight_layout()
    plt.savefig("diagrams/flowchart_chaining.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/flowchart_chaining.png")


# 2. System Architecture Diagram
def generate_architecture_diagram():
    fig, ax = plt.subplots(figsize=(12, 6.5), dpi=300)
    ax.set_title("Medical Diagnosis Expert System - Architectural Overview", fontsize=14, fontweight="bold", pad=15)
    ax.axis('off')

    # Component boxes
    components = [
        ("User Interface Layer\n(CLI & Flask Web UI)", 0.15, 0.5, "#e0f2fe", "#0284c7"),
        ("Inference Engine\n• Forward Chainer\n• Backward Chainer\n• Conflict Resolver", 0.5, 0.5, "#fef3c7", "#d97706"),
        ("Knowledge Base\n• 12 Production Rules\n• 24 Clinical Symptoms\n• 12 Disease Profiles", 0.85, 0.72, "#dcfce7", "#16a34a"),
        ("Working Memory\n(Dynamic Fact Base)\n• Known Symptoms\n• Derived Intermediate Facts", 0.85, 0.28, "#ede9fe", "#7c3aed"),
        ("Explanation Facility\n• Step-by-Step Audit Trail\n• Why/How Justifications", 0.5, 0.12, "#ffe4e6", "#e11d48")
    ]

    for title, x, y, face, edge in components:
        bbox = dict(boxstyle="round,pad=0.8", facecolor=face, edgecolor=edge, linewidth=2)
        ax.text(x, y, title, ha="center", va="center", fontsize=9.5, fontweight="600", bbox=bbox)

    # Arrows between components
    # UI <-> Inference Engine
    ax.annotate('', xy=(0.36, 0.52), xytext=(0.28, 0.52),
                arrowprops=dict(facecolor='#0284c7', edgecolor='#0284c7', width=2, headwidth=7))
    ax.annotate('', xy=(0.28, 0.48), xytext=(0.36, 0.48),
                arrowprops=dict(facecolor='#0284c7', edgecolor='#0284c7', width=2, headwidth=7))

    # Inference Engine <-> Knowledge Base
    ax.annotate('', xy=(0.72, 0.68), xytext=(0.62, 0.57),
                arrowprops=dict(facecolor='#16a34a', edgecolor='#16a34a', width=2, headwidth=7))
    ax.annotate('', xy=(0.62, 0.57), xytext=(0.72, 0.68),
                arrowprops=dict(facecolor='#16a34a', edgecolor='#16a34a', width=2, headwidth=7))

    # Inference Engine <-> Working Memory
    ax.annotate('', xy=(0.72, 0.32), xytext=(0.62, 0.43),
                arrowprops=dict(facecolor='#7c3aed', edgecolor='#7c3aed', width=2, headwidth=7))
    ax.annotate('', xy=(0.62, 0.43), xytext=(0.72, 0.32),
                arrowprops=dict(facecolor='#7c3aed', edgecolor='#7c3aed', width=2, headwidth=7))

    # Inference Engine -> Explanation Facility
    ax.annotate('', xy=(0.5, 0.22), xytext=(0.5, 0.38),
                arrowprops=dict(facecolor='#e11d48', edgecolor='#e11d48', width=2, headwidth=7))

    plt.tight_layout()
    plt.savefig("diagrams/system_architecture.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/system_architecture.png")


# 3. Disease Coverage & Symptom Complexity Chart
def generate_metrics_chart():
    diseases = ["COVID-19", "Common Cold", "Flu", "Malaria", "Typhoid", 
                "Strep Throat", "Allergy", "Dengue", "Migraine", "Food Poisoning", "Bronchitis", "Pneumonia"]
    symptom_counts = [4, 4, 5, 4, 5, 3, 3, 4, 3, 4, 4, 4]
    severity_colors = ['#ef4444', '#10b981', '#f59e0b', '#ef4444', '#ef4444', 
                       '#f59e0b', '#10b981', '#ef4444', '#f59e0b', '#f59e0b', '#f59e0b', '#ef4444']

    plt.figure(figsize=(11, 5), dpi=300)
    bars = plt.bar(diseases, symptom_counts, color=severity_colors, edgecolor='#334155', linewidth=1)
    plt.title("Knowledge Base Rule Specification: Required Antecedents per Target Condition", fontsize=12, fontweight="bold", pad=12)
    plt.xlabel("Target Disease Condition", fontweight="bold", labelpad=8)
    plt.ylabel("Number of Required Antecedent Symptoms", fontweight="bold", labelpad=8)
    plt.xticks(rotation=35, ha='right', fontsize=9)
    plt.grid(axis='y', linestyle='--', alpha=0.5)

    for bar in bars:
        yval = bar.get_height()
        plt.text(bar.get_x() + bar.get_width()/2.0, yval + 0.12, int(yval), ha='center', va='bottom', fontsize=9, fontweight='bold')

    # Custom legend for severity
    legend_elements = [
        patches.Patch(facecolor='#10b981', label='Mild Severity'),
        patches.Patch(facecolor='#f59e0b', label='Moderate Severity'),
        patches.Patch(facecolor='#ef4444', label='Severe / Urgent Severity')
    ]
    plt.legend(handles=legend_elements, loc='upper right', frameon=True)

    plt.tight_layout()
    plt.savefig("diagrams/disease_rules_chart.png", dpi=300, bbox_inches="tight")
    plt.close()
    print("Saved diagrams/disease_rules_chart.png")


if __name__ == "__main__":
    generate_chaining_diagram()
    generate_architecture_diagram()
    generate_metrics_chart()
    print("All diagrams generated successfully.")
