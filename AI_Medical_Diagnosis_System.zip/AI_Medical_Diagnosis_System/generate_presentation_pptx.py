"""
Generate a professional, beginner-friendly Microsoft PowerPoint (.pptx) presentation
for the AI Medical Diagnosis System (Rule-Based Expert System).
"""

from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

def create_presentation():
    prs = Presentation()
    # Set 16:9 widescreen
    prs.slide_width = Inches(13.333)
    prs.slide_height = Inches(7.5)

    # Color Palette
    PRIMARY = RGBColor(2, 132, 199)       # #0284c7
    PRIMARY_DARK = RGBColor(15, 23, 42)    # #0f172a
    ACCENT = RGBColor(16, 185, 129)       # #10b981
    BG_LIGHT = RGBColor(248, 250, 252)    # #f8fafc
    CARD_BG = RGBColor(255, 255, 255)     # #ffffff
    TEXT_MAIN = RGBColor(30, 41, 59)      # #1e293b
    TEXT_MUTED = RGBColor(100, 116, 139)  # #64748b
    BORDER_COLOR = RGBColor(226, 232, 240)# #e2e8f0

    blank_layout = prs.slide_layouts[6]

    def add_header(slide, tag_text, title_text):
        # Background fill
        bg = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
        bg.fill.solid()
        bg.fill.fore_color.rgb = BG_LIGHT
        bg.line.color.rgb = BG_LIGHT

        # Top tag
        tx_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.5), Inches(0.4))
        tf = tx_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = tag_text.upper()
        p.font.name = "Calibri"
        p.font.size = Pt(11)
        p.font.bold = True
        p.font.color.rgb = PRIMARY

        # Title
        tx_title = slide.shapes.add_textbox(Inches(0.8), Inches(0.7), Inches(11.5), Inches(0.8))
        tf_title = tx_title.text_frame
        tf_title.word_wrap = True
        p_title = tf_title.paragraphs[0]
        p_title.text = title_text
        p_title.font.name = "Calibri"
        p_title.font.size = Pt(24)
        p_title.font.bold = True
        p_title.font.color.rgb = PRIMARY_DARK

    def add_card(slide, left, top, width, height, title, items, highlight=False):
        card = slide.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, left, top, width, height)
        card.fill.solid()
        card.fill.fore_color.rgb = CARD_BG
        card.line.color.rgb = PRIMARY if highlight else BORDER_COLOR
        card.line.width = Pt(2 if highlight else 1)

        # Title
        t_box = slide.shapes.add_textbox(left + Inches(0.2), top + Inches(0.15), width - Inches(0.4), Inches(0.5))
        tf = t_box.text_frame
        tf.word_wrap = True
        p = tf.paragraphs[0]
        p.text = title
        p.font.name = "Calibri"
        p.font.size = Pt(14)
        p.font.bold = True
        p.font.color.rgb = PRIMARY if highlight else PRIMARY_DARK

        # Items
        b_box = slide.shapes.add_textbox(left + Inches(0.2), top + Inches(0.65), width - Inches(0.4), height - Inches(0.8))
        tf_b = b_box.text_frame
        tf_b.word_wrap = True
        for idx, itm in enumerate(items):
            p_itm = tf_b.paragraphs[0] if idx == 0 else tf_b.add_paragraph()
            p_itm.text = f"• {itm}"
            p_itm.font.name = "Calibri"
            p_itm.font.size = Pt(11)
            p_itm.font.color.rgb = TEXT_MAIN
            p_itm.space_after = Pt(4)

    # ================= SLIDE 1: TITLE SLIDE =================
    s1 = prs.slides.add_slide(blank_layout)
    bg1 = s1.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg1.fill.solid()
    bg1.fill.fore_color.rgb = RGBColor(240, 249, 255) # very light blue
    bg1.line.color.rgb = RGBColor(240, 249, 255)

    # Badge
    b1 = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(4.6), Inches(0.8), Inches(4.1), Inches(0.45))
    b1.fill.solid()
    b1.fill.fore_color.rgb = PRIMARY
    b1.line.color.rgb = PRIMARY
    p = b1.text_frame.paragraphs[0]
    p.text = "AI MINI PROJECT PRESENTATION | 2025-26"
    p.font.name = "Calibri"
    p.font.size = Pt(11)
    p.font.bold = True
    p.font.color.rgb = CARD_BG
    p.alignment = PP_ALIGN.CENTER

    # Main Title
    t_box = s1.shapes.add_textbox(Inches(1.0), Inches(1.5), Inches(11.3), Inches(1.8))
    tf = t_box.text_frame
    tf.word_wrap = True
    p = tf.paragraphs[0]
    p.text = "AI Medical Diagnosis System\n(Rule-Based Expert System)"
    p.font.name = "Calibri"
    p.font.size = Pt(34)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_DARK
    p.alignment = PP_ALIGN.CENTER

    p2 = tf.add_paragraph()
    p2.text = "Automated Clinical Decision Support Using Forward & Backward Chaining"
    p2.font.name = "Calibri"
    p2.font.size = Pt(17)
    p2.font.color.rgb = PRIMARY
    p2.alignment = PP_ALIGN.CENTER

    # Author Box
    c_auth = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(2.2), Inches(3.7), Inches(4.2), Inches(2.8))
    c_auth.fill.solid()
    c_auth.fill.fore_color.rgb = CARD_BG
    c_auth.line.color.rgb = BORDER_COLOR
    tf_a = c_auth.text_frame
    tf_a.word_wrap = True
    p = tf_a.paragraphs[0]
    p.text = "SUBMITTED BY"
    p.font.name = "Calibri"
    p.font.size = Pt(11)
    p.font.bold = True
    p.font.color.rgb = PRIMARY
    
    p = tf_a.add_paragraph()
    p.text = "Tanvi Sagar Unde\nClass: Third Year Engineering (TE)\nBranch: Computer Science (Div: A)\nRoll No / Seat No: 32170"
    p.font.name = "Calibri"
    p.font.size = Pt(12)
    p.font.color.rgb = TEXT_MAIN

    # Guide Box
    c_guide = s1.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(6.9), Inches(3.7), Inches(4.2), Inches(2.8))
    c_guide.fill.solid()
    c_guide.fill.fore_color.rgb = CARD_BG
    c_guide.line.color.rgb = BORDER_COLOR
    tf_g = c_guide.text_frame
    tf_g.word_wrap = True
    p = tf_g.paragraphs[0]
    p.text = "GUIDED BY & INSTITUTION"
    p.font.name = "Calibri"
    p.font.size = Pt(11)
    p.font.bold = True
    p.font.color.rgb = PRIMARY
    
    p = tf_g.add_paragraph()
    p.text = "Prof. Vinay Hiwanj (Internal Guide)\nDr. D. Y. Patil Technical Campus, Talegaon\nSavitribai Phule Pune University, Pune\nIndustry: Codec Technologies India"
    p.font.name = "Calibri"
    p.font.size = Pt(12)
    p.font.color.rgb = TEXT_MAIN

    # ================= SLIDE 2: MOTIVATION & PROBLEM STATEMENT =================
    s2 = prs.slides.add_slide(blank_layout)
    add_header(s2, "Context & Clinical Need", "Problem Statement & Project Motivation")
    add_card(s2, Inches(0.8), Inches(1.7), Inches(5.6), Inches(5.0), "Healthcare Triage Challenges", [
        "Primary health centers often face severe doctor-to-patient shortages.",
        "Delays in preliminary diagnostic triage lead to disease escalation.",
        "Early detection of infectious diseases (COVID-19, Malaria, Typhoid) significantly improves patient recovery.",
        "Need for an accessible, offline-capable clinical decision support system for health workers."
    ])
    add_card(s2, Inches(6.8), Inches(1.7), Inches(5.6), Inches(5.0), "Why Rule-Based AI (Expert Systems)?", [
        "Explainability & Transparency: Doctors cannot trust black-box deep learning without medical justifications.",
        "Deterministic Reasoning: Zero hallucination; every diagnostic output is strictly grounded in medical rules.",
        "Auditability: Generates human-readable traces detailing exactly which symptoms fired which rules.",
        "Lightweight: Runs on standard computers without expensive GPUs or cloud APIs."
    ], highlight=True)

    # ================= SLIDE 3: WHAT IS AN EXPERT SYSTEM? =================
    s3 = prs.slides.add_slide(blank_layout)
    add_header(s3, "Theoretical Foundations", "Architecture of a Rule-Based Expert System")
    add_card(s3, Inches(0.8), Inches(1.7), Inches(3.6), Inches(5.0), "1. Knowledge Base", [
        "Permanent repository of domain knowledge.",
        "Stores 24 clinical symptoms and 12 disease profiles.",
        "Encodes 12 production rules in IF-THEN format.",
        "Includes diagnostic and multi-step intermediate rules."
    ])
    add_card(s3, Inches(4.8), Inches(1.7), Inches(3.6), Inches(5.0), "2. Working Memory", [
        "Dynamic fact base for the active patient.",
        "Stores input symptoms reported by user.",
        "Records intermediate derived facts.",
        "Maintains system state during execution cycles."
    ], highlight=True)
    add_card(s3, Inches(8.8), Inches(1.7), Inches(3.6), Inches(5.0), "3. Inference Engine", [
        "The reasoning brain of the system.",
        "Forward Chaining: Data-driven bottom-up pattern matching.",
        "Backward Chaining: Goal-driven top-down recursive verification.",
        "Explanation Facility: Step-by-step reasoning audit logs."
    ])

    # ================= SLIDE 4: FORWARD CHAINING =================
    s4 = prs.slides.add_slide(blank_layout)
    add_header(s4, "Reasoning Paradigm 1", "Forward Chaining (Data-Driven / Bottom-Up)")
    add_card(s4, Inches(0.8), Inches(1.7), Inches(5.6), Inches(5.0), "Algorithmic Workflow", [
        "Principle: Starts with known facts (symptoms) and moves forward to derive diagnoses.",
        "Step 1: Patient selects observed symptoms -> Loaded into Working Memory.",
        "Step 2: Engine scans Knowledge Base for rules whose antecedents (IF) are satisfied.",
        "Step 3: Matching rules FIRE (Modus Ponens inference).",
        "Step 4: Consequents (THEN) are asserted as new facts into Working Memory.",
        "Step 5: Process repeats in cycles until no new rules can fire (quiescent state).",
        "Clinical Use: Open general health triage when a patient reports multiple symptoms."
    ])
    add_card(s4, Inches(6.8), Inches(1.7), Inches(5.6), Inches(5.0), "Practical Demonstration Case", [
        "Patient Symptoms: [fever, cough, fatigue, loss_of_taste_smell]",
        "Execution Cycle 1:",
        "• Checks Rule R_COLD -> Missing runny_nose (Did NOT fire)",
        "• Checks Rule R_COVID -> Antecedents [fever, cough, fatigue, loss_of_taste_smell] ALL SATISFIED!",
        "• Rule R_COVID FIRES -> Asserts 'COVID-19' into Working Memory.",
        "Conclusion: Confirmed Coronavirus Disease (COVID-19)",
        "Severity: Moderate to Severe | Specialist: Pulmonologist",
        "Precautions: Isolate in well-ventilated room, monitor SpO2, stay hydrated."
    ], highlight=True)

    # ================= SLIDE 5: BACKWARD CHAINING =================
    s5 = prs.slides.add_slide(blank_layout)
    add_header(s5, "Reasoning Paradigm 2", "Backward Chaining (Goal-Driven / Top-Down)")
    add_card(s5, Inches(0.8), Inches(1.7), Inches(5.6), Inches(5.0), "Algorithmic Workflow", [
        "Principle: Starts with a goal/hypothesis and works backward to check supporting data.",
        "Step 1: User or doctor selects a target disease hypothesis (e.g., 'Malaria').",
        "Step 2: Engine locates rules concluding that disease.",
        "Step 3: Required antecedents become sub-goals to prove.",
        "Step 4: Recursively evaluates sub-goals; if unknown, interactively queries patient (Yes/No).",
        "Step 5: If all required antecedents resolve to True, hypothesis is CONFIRMED; otherwise REFUTED.",
        "Clinical Use: Verifying or ruling out a suspected critical condition."
    ])
    add_card(s5, Inches(6.8), Inches(1.7), Inches(5.6), Inches(5.0), "Interactive Clinical Query Trace", [
        "Target Goal: 'Malaria' -> Rule R_MALARIA",
        "• Sub-goal 1: High Fever -> Query: Does patient have high fever? -> YES",
        "• Sub-goal 2: Chills -> Query: Does patient experience chills? -> YES",
        "• Sub-goal 3: Sweating -> Query: Does patient experience sweating? -> YES",
        "• Sub-goal 4: Headache -> Query: Does patient have headache? -> YES",
        "Result: ALL 4 CONDITIONS SATISFIED -> Hypothesis CONFIRMED!",
        "Specialist: Infectious Disease Specialist / Physician",
        "Immediate Action: Blood smear microscopy and antimalarial ACT regimen."
    ], highlight=True)

    # ================= SLIDE 6: COMPARISON TABLE =================
    s6 = prs.slides.add_slide(blank_layout)
    add_header(s6, "Algorithmic Synthesis", "Forward vs. Backward Chaining Comparison")
    
    # Create Table
    rows, cols = 6, 3
    left, top, width, height = Inches(0.8), Inches(1.8), Inches(11.6), Inches(4.8)
    table_shape = s6.shapes.add_table(rows, cols, left, top, width, height)
    tbl = table_shape.table
    tbl.columns[0].width = Inches(3.0)
    tbl.columns[1].width = Inches(4.3)
    tbl.columns[2].width = Inches(4.3)

    comp_headers = ["Evaluation Criteria", "Forward Chaining (Data-Driven)", "Backward Chaining (Goal-Driven)"]
    comp_rows = [
        ("Reasoning Direction", "Bottom-Up (Data -> Conclusions)", "Top-Down (Hypothesis -> Supporting Facts)"),
        ("Starting Point", "Observed patient symptoms (facts)", "Suspected disease condition (goal)"),
        ("Search Space", "Explores all possible consequences", "Focused strictly on target goal's sub-tree"),
        ("User Interaction", "Symptom selection upfront at start", "Interactive, targeted Yes/No dialogue"),
        ("Primary Healthcare Role", "Comprehensive screening & preliminary triage", "Hypothesis verification & ruling out critical diseases")
    ]

    for c_idx, h_text in enumerate(comp_headers):
        cell = tbl.cell(0, c_idx)
        cell.text = h_text
        cell.fill.solid()
        cell.fill.fore_color.rgb = PRIMARY
        p = cell.text_frame.paragraphs[0]
        p.font.name = "Calibri"
        p.font.size = Pt(13)
        p.font.bold = True
        p.font.color.rgb = CARD_BG

    for r_idx, (crit, fc, bc) in enumerate(comp_rows, 1):
        for c_idx, val in enumerate([crit, fc, bc]):
            cell = tbl.cell(r_idx, c_idx)
            cell.text = val
            cell.fill.solid()
            cell.fill.fore_color.rgb = RGBColor(241, 245, 249) if r_idx % 2 == 1 else CARD_BG
            p = cell.text_frame.paragraphs[0]
            p.font.name = "Calibri"
            p.font.size = Pt(11)
            p.font.color.rgb = TEXT_MAIN
            if c_idx == 0:
                p.font.bold = True

    # ================= SLIDE 7: KNOWLEDGE BASE BREAKDOWN =================
    s7 = prs.slides.add_slide(blank_layout)
    add_header(s7, "Domain Engineering", "Knowledge Base Catalog & Disease Coverage")
    add_card(s7, Inches(0.8), Inches(1.7), Inches(3.6), Inches(5.0), "24 Clinical Symptoms", [
        "General: Fever, High Fever, Chills, Fatigue, Body Ache, Sweating",
        "Respiratory: Cough, Shortness of Breath, Sore Throat, Wheezing",
        "Neurological: Headache, Migraine, Light Sensitivity, Loss of Taste/Smell",
        "Digestive: Nausea, Vomiting, Abdominal Pain, Diarrhea, Loss of Appetite",
        "ENT & Sensory: Sneezing, Runny Nose, Swollen Tonsils, Itchy Eyes"
    ])
    add_card(s7, Inches(4.8), Inches(1.7), Inches(3.6), Inches(5.0), "12 Target Pathologies", [
        "COVID-19 (Viral Respiratory)",
        "Influenza / Flu (Viral Systemic)",
        "Common Cold (Upper Respiratory)",
        "Malaria (Parasitic Vector-Borne)",
        "Typhoid Fever (Bacterial Systemic)",
        "Dengue Fever (Viral Vector-Borne)",
        "Strep Throat (Bacterial ENT)",
        "Allergic Rhinitis (Immunological)",
        "Migraine (Neurological)",
        "Food Poisoning (Gastrointestinal)",
        "Bronchitis & Pneumonia (Pulmonary)"
    ], highlight=True)
    add_card(s7, Inches(8.8), Inches(1.7), Inches(3.6), Inches(5.0), "Production Rule Engine", [
        "12 Crisp IF-THEN Rules.",
        "Diagnostic Rules: Conclude final disease conditions.",
        "Intermediate Rules: Multi-step inference (e.g., high_fever + chills -> severe_systemic_infection).",
        "Differential Scoring: Partial matching % if not 100% textbook match.",
        "Metadata: Precautions, severity tiers, and specialist recommendations."
    ])

    # ================= SLIDE 8: SYSTEM ARCHITECTURE =================
    s8 = prs.slides.add_slide(blank_layout)
    add_header(s8, "System Design & Pipeline", "Software Architecture & Technology Stack")
    add_card(s8, Inches(0.8), Inches(1.7), Inches(5.6), Inches(5.0), "Technology Stack", [
        "Backend: Python 3.13 (Clean, PEP-8 compliant modular architecture).",
        "Web Framework: Flask 3.1.2 RESTful API server.",
        "Frontend: Semantic HTML5, CSS3 Variables, Asynchronous JavaScript (Fetch API).",
        "Zero Heavy ML Dependencies: Fully deterministic, fast (<10ms inference), and runs locally without GPU.",
        "Data Structures: Sets and Hash Maps for O(1) antecedent matching."
    ])
    add_card(s8, Inches(6.8), Inches(1.7), Inches(5.6), Inches(5.0), "Modular Codebase Organization", [
        "knowledge_base.py: Symptoms dictionary, disease metadata, and IF-THEN production rules.",
        "inference_engine.py: Pure implementations of ForwardChainingEngine and BackwardChainingEngine.",
        "cli_diagnosis.py: Interactive menu-driven console CLI.",
        "app.py: Full-stack Flask application serving web APIs.",
        "Medical_Diagnosis_System_App.html: Standalone zero-setup web app."
    ], highlight=True)

    # ================= SLIDE 9: TEST RESULTS & VERIFICATION =================
    s9 = prs.slides.add_slide(blank_layout)
    add_header(s9, "Quality Assurance", "Unit Testing & Algorithmic Verification")
    add_card(s9, Inches(0.8), Inches(1.7), Inches(5.6), Inches(5.0), "Automated Test Suite (5/5 Passed)", [
        "Test 1: Forward Chaining COVID-19 (fever, cough, fatigue, loss of taste/smell) -> PASSED",
        "Test 2: Forward Chaining Malaria (high_fever, chills, sweating, headache) + intermediate fact deduction -> PASSED",
        "Test 3: Backward Chaining Common Cold hypothesis verification -> PASSED",
        "Test 4: Backward Chaining Strep Throat interactive questions -> PASSED",
        "Test 5: Backward Chaining Migraine negative refutation -> PASSED"
    ])
    add_card(s9, Inches(6.8), Inches(1.7), Inches(5.6), Inches(5.0), "Performance Metrics", [
        "Accuracy & Determinism: 100% reproducible results.",
        "Inference Speed: Average execution time < 8 milliseconds per consultation.",
        "Cycle Efficiency: Quiescent state reached within 2-3 execution cycles.",
        "Explainability Coverage: 100% of diagnoses accompanied by full step-by-step reasoning audit logs.",
        "Robustness: Prevents circular dependency loops using visited goal sets."
    ], highlight=True)

    # ================= SLIDE 10: USER INTERFACES =================
    s10 = prs.slides.add_slide(blank_layout)
    add_header(s10, "User Experience & Deployment", "Dual User Interface Implementation")
    add_card(s10, Inches(0.8), Inches(1.7), Inches(5.6), Inches(5.0), "Interactive Web Application", [
        "Modern Healthcare Dashboard built with responsive CSS.",
        "Quick Presets: 1-click test cases for COVID-19, Malaria, Cold, and Allergies.",
        "Differential Scoring: Progress bars showing % match for partial symptoms.",
        "Interactive Backward Chaining Modal: Steps through Yes/No symptom checks.",
        "Reasoning Trace Viewer: Collapsible audit trail for full transparency."
    ], highlight=True)
    add_card(s10, Inches(6.8), Inches(1.7), Inches(5.6), Inches(5.0), "Terminal CLI & Standalone App", [
        "Command Line Interface (cli_diagnosis.py): Accessible in any terminal environment.",
        "Numbered symptom selector with category tags.",
        "Interactive question prompts during backward chaining.",
        "Standalone HTML App (Medical_Diagnosis_System_App.html): Opens in any browser with zero installation.",
        "One-Click Launcher (Run_App.bat): Launches Flask and browser instantly."
    ])

    # ================= SLIDE 11: CHALLENGES & SOLUTIONS =================
    s11 = prs.slides.add_slide(blank_layout)
    add_header(s11, "Engineering Insights", "Technical Challenges & Solutions")
    add_card(s11, Inches(0.8), Inches(1.7), Inches(3.6), Inches(5.0), "1. Incomplete Symptoms", [
        "Challenge: Real patients rarely present 100% textbook symptoms.",
        "Solution: Formulated a Differential Matching Algorithm calculating % similarity and displaying missing conditions."
    ])
    add_card(s11, Inches(4.8), Inches(1.7), Inches(3.6), Inches(5.0), "2. Circular Loops", [
        "Challenge: Recursive backward chaining can enter infinite loops if rules cross-reference.",
        "Solution: Incorporated a visited-goals tracking set to prune circular dependencies."
    ], highlight=True)
    add_card(s11, Inches(8.8), Inches(1.7), Inches(3.6), Inches(5.0), "3. Clinical Trust", [
        "Challenge: Providing clear justification for medical recommendations.",
        "Solution: Built an Explanation Facility generating step-by-step audit logs."
    ])

    # ================= SLIDE 12: FUTURE RECOMMENDATIONS =================
    s12 = prs.slides.add_slide(blank_layout)
    add_header(s12, "Roadmap & Scalability", "Recommendations for Future Enhancements")
    add_card(s12, Inches(0.8), Inches(1.7), Inches(3.6), Inches(5.0), "Certainty Factors & Fuzzy Logic", [
        "Integrate MYCIN certainty factors (0.0 to 1.0) to model subjective symptom severity.",
        "Incorporate fuzzy membership functions for terms like 'mild fever' vs 'high fever'."
    ])
    add_card(s12, Inches(4.8), Inches(1.7), Inches(3.6), Inches(5.0), "Mobile App for Rural Triage", [
        "Package the expert system as an offline Flutter / Android app for community health workers.",
        "Enable low-cost mobile triage in remote primary health sub-centers without internet."
    ], highlight=True)
    add_card(s12, Inches(8.8), Inches(1.7), Inches(3.6), Inches(5.0), "EHR & FHIR Integration", [
        "Connect with Hospital Information Systems via Fast Healthcare Interoperability Resources (FHIR).",
        "Automatically ingest patient electronic medical history and vital signs."
    ])

    # ================= SLIDE 13: CONCLUSION =================
    s13 = prs.slides.add_slide(blank_layout)
    bg13 = s13.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg13.fill.solid()
    bg13.fill.fore_color.rgb = RGBColor(240, 249, 255)
    bg13.line.color.rgb = RGBColor(240, 249, 255)

    b13 = s13.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(4.8), Inches(1.0), Inches(3.7), Inches(0.45))
    b13.fill.solid()
    b13.fill.fore_color.rgb = ACCENT
    b13.line.color.rgb = ACCENT
    p = b13.text_frame.paragraphs[0]
    p.text = "PROJECT SUMMARY & TAKEAWAYS"
    p.font.name = "Calibri"
    p.font.size = Pt(11)
    p.font.bold = True
    p.font.color.rgb = CARD_BG
    p.alignment = PP_ALIGN.CENTER

    t_box13 = s13.shapes.add_textbox(Inches(1.2), Inches(1.8), Inches(10.9), Inches(4.8))
    tf13 = t_box13.text_frame
    tf13.word_wrap = True

    p = tf13.paragraphs[0]
    p.text = "Summary of Project Achievements"
    p.font.name = "Calibri"
    p.font.size = Pt(28)
    p.font.bold = True
    p.font.color.rgb = PRIMARY_DARK
    p.alignment = PP_ALIGN.CENTER

    achievements = [
        "Successfully engineered a deterministic, explainable Medical Diagnosis Expert System in Python.",
        "Implemented both Forward Chaining (data-driven) and Backward Chaining (goal-driven) from first principles.",
        "Formulated a clinical Knowledge Base comprising 24 symptoms, 12 pathologies, and 12 production rules.",
        "Developed dual user interfaces: an interactive terminal CLI and a responsive web dashboard.",
        "Achieved 100% test pass rate across all verification suites with sub-10ms response latency."
    ]

    for itm in achievements:
        p_itm = tf13.add_paragraph()
        p_itm.text = f"✔  {itm}"
        p_itm.font.name = "Calibri"
        p_itm.font.size = Pt(15)
        p_itm.font.color.rgb = TEXT_MAIN
        p_itm.space_before = Pt(10)

    # ================= SLIDE 14: THANK YOU & Q&A =================
    s14 = prs.slides.add_slide(blank_layout)
    bg14 = s14.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg14.fill.solid()
    bg14.fill.fore_color.rgb = PRIMARY_DARK
    bg14.line.color.rgb = PRIMARY_DARK

    t_box14 = s14.shapes.add_textbox(Inches(1.5), Inches(2.0), Inches(10.3), Inches(3.5))
    tf14 = t_box14.text_frame
    tf14.word_wrap = True

    p = tf14.paragraphs[0]
    p.text = "Thank You!"
    p.font.name = "Calibri"
    p.font.size = Pt(46)
    p.font.bold = True
    p.font.color.rgb = CARD_BG
    p.alignment = PP_ALIGN.CENTER

    p2 = tf14.add_paragraph()
    p2.text = "Questions, Feedback & Discussion Are Welcome"
    p2.font.name = "Calibri"
    p2.font.size = Pt(22)
    p2.font.color.rgb = PRIMARY
    p2.alignment = PP_ALIGN.CENTER
    p2.space_before = Pt(12)

    p3 = tf14.add_paragraph()
    p3.text = "Tanvi Sagar Unde | TE Computer Science (Roll No: 32170)\nProf. Vinay Hiwanj | Dr. D. Y. Patil Technical Campus, SPPU Pune\nCodec Technologies India"
    p3.font.name = "Calibri"
    p3.font.size = Pt(14)
    p3.font.color.rgb = RGBColor(148, 163, 184)
    p3.alignment = PP_ALIGN.CENTER
    p3.space_before = Pt(24)

    output_file = "Medical_Diagnosis_System_Presentation.pptx"
    prs.save(output_file)
    print(f"PowerPoint presentation successfully saved at: {output_file}")

if __name__ == "__main__":
    create_presentation()
