@echo off
title AI Medical Diagnosis Expert System Launcher
color 0B
echo ======================================================================
echo          AI MEDICAL DIAGNOSIS SYSTEM (RULE-BASED EXPERT SYSTEM)
echo                 Forward Chaining and Backward Chaining
echo ======================================================================
echo.
echo [1/2] Starting local Python server...
echo [2/2] Opening web browser at http://127.0.0.1:5000...
echo.
echo (Keep this terminal window open while using the application)
echo (Press Ctrl+C in this window when you want to stop the server)
echo.

cd /d "%~dp0"
python app.py

pause
