"""
Generate the complete, official Word Document (.docx) report strictly adhering to the user's
given template for SAVITRIBAI PHULE PUNE UNIVERSITY, PUNE and DR. D. Y. PATIL TECHNICAL CAMPUS,
customized for the AI Medical Diagnosis System (Rule-Based Expert System using Forward and Backward Chaining)
completed during the Internship at Codec Technologies India.
"""

import os
from docx import Document
from docx.shared import Inches, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml import parse_xml
from docx.oxml.ns import nsdecls

def set_cell_background(cell, fill_hex):
    tcPr = cell._tc.get_or_add_tcPr()
    shd = parse_xml(f'<w:shd {nsdecls("w")} w:fill="{fill_hex}"/>')
    tcPr.append(shd)

def set_cell_margins(cell, top=100, bottom=100, left=150, right=150):
    tcPr = cell._tc.get_or_add_tcPr()
    tcMar = parse_xml(f'<w:tcMar {nsdecls("w")}><w:top w:w="{top}" w:type="dxa"/><w:bottom w:w="{bottom}" w:type="dxa"/><w:left w:w="{left}" w:type="dxa"/><w:right w:w="{right}" w:type="dxa"/></w:tcMar>')
    tcPr.append(tcMar)

def style_heading(doc, text, size=Pt(13), space_before=Pt(14), space_after=Pt(6), color=RGBColor(15, 23, 42)):
    p = doc.add_paragraph()
    p.paragraph_format.space_before = space_before
    p.paragraph_format.space_after = space_after
    p.paragraph_format.keep_with_next = True
    run = p.add_run(text)
    run.font.name = "Calibri"
    run.font.size = size
    run.font.bold = True
    run.font.color.rgb = color
    return p

def add_p(doc, text, bold_prefix="", space_after=Pt(6)):
    p = doc.add_paragraph()
    p.paragraph_format.space_after = space_after
    p.paragraph_format.line_spacing = 1.15
    if bold_prefix:
        r_bold = p.add_run(bold_prefix)
        r_bold.font.name = "Calibri"
        r_bold.font.size = Pt(11)
        r_bold.font.bold = True
    r_text = p.add_run(text)
    r_text.font.name = "Calibri"
    r_text.font.size = Pt(11)
    return p

def generate_report():
    doc = Document()

    for section in doc.sections:
        section.top_margin = Inches(1)
        section.bottom_margin = Inches(1)
        section.left_margin = Inches(1)
        section.right_margin = Inches(1)

    # ================= 1. TITLE PAGE =================
    p = doc.add_paragraph()
    p.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p.add_run("SAVITRIBAI PHULE PUNE UNIVERSITY, PUNE\n")
    r.font.name = "Calibri"
    r.font.size = Pt(16)
    r.font.bold = True
    r.font.color.rgb = RGBColor(15, 23, 42)

    p2 = doc.add_paragraph()
    p2.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p2.add_run("A PRELIMINARY INTERNSHIP REPORT\nON\n")
    r.font.size = Pt(13)
    r.font.bold = True
    r.font.color.rgb = RGBColor(71, 85, 105)

    r_title = p2.add_run("“AI MEDICAL DIAGNOSIS SYSTEM\n(RULE-BASED EXPERT SYSTEM USING FORWARD AND BACKWARD CHAINING)”\n")
    r_title.font.size = Pt(14.5)
    r_title.font.bold = True
    r_title.font.color.rgb = RGBColor(2, 132, 199)

    p3 = doc.add_paragraph()
    p3.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p3.add_run("SUBMITTED TO THE SAVITRIBAI PHULE PUNE UNIVERSITY, PUNE\nTHIRD YEAR ENGINEERING (COMPUTER SCIENCE)\n\n")
    r.font.size = Pt(11)
    r.font.bold = True

    r = p3.add_run("D.Y. Patil Academic Education Excellence Federation’s\nDr.D.Y.Patil Technical Campus\n(Engineering and MCA)\n")
    r.font.size = Pt(12)
    r.font.bold = True
    r.font.color.rgb = RGBColor(30, 41, 59)
    r = p3.add_run("Sr.No.32/1/A/7, Near Talegaon Railway Station, A/P Varale, Talegaon Dabhade\nTal-Maval, Dist-Pune 410507\nWebsite: www.dypatiltcs.com\n\n")
    r.font.size = Pt(9.5)
    r.font.italic = True

    p4 = doc.add_paragraph()
    p4.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p4.add_run("SUBMITTED BY\n“Tanvi Sagar Unde”\nClass:  TE-A\nRoll No/Seat No.: 32170\n\n")
    r.font.size = Pt(11.5)
    r.font.bold = True

    r = p4.add_run("GUIDED BY\n– Prof. Vinay Hiwanj\n2025-26\n\n")
    r.font.size = Pt(11)
    r.font.bold = True
    r.font.color.rgb = RGBColor(51, 65, 85)

    r_c = p4.add_run("Conducts of the Internship Training\nPlace of Internship: Hybrid\nSupervisor: Ms. Vaishali Shrivastava\nDepartment Supervisor: Dr. Anurag Shrivastava")
    r_c.font.size = Pt(10)
    r_c.font.italic = True

    doc.add_page_break()

    # ================= 2. CERTIFICATE =================
    style_heading(doc, "Certificate", size=Pt(16), space_before=Pt(10), space_after=Pt(12), color=RGBColor(2, 132, 199))
    
    cert_text = (
        "This is to certified that the Internship Report (310255) has been successfully completed by: "
        "Student Name: Tanvi Sagar Unde Class: TE Division: A Roll No/Seat No.: 32170 as partial fulfillment of "
        "engineering in Computer Science under the Savitribai Phule Pune University, during the academic year 2025-26.\n\n"
        "The said work has been assessed by us and we are satisfied that the same is up to the standard envisaged "
        "for the level of the course and that the said work may be presented to the examiner."
    )
    add_p(doc, cert_text, space_after=Pt(20))

    p_loc = doc.add_paragraph()
    p_loc.add_run("Date:\nPlace: Varale, Talegaon, Pune\n\n\n")

    sig_table = doc.add_table(rows=2, cols=2)
    sig_table.alignment = WD_TABLE_ALIGNMENT.CENTER
    sig_table.autofit = False

    sig_data = [
        ("Prof. Vinay Hiwanj\nInternal Guide\nDepartment of Computer Engineering", 
         "Dr. Sandip A. Kahate\nHead\nDepartment of Computer Science"),
        ("Prof. Swapnil More\nInternship Coordinator (Comp. Science Dept)", 
         "Dr. S. D. Shirbahadurkar\nPrincipal\nDr. D. Y. Patil Technical Campus")
    ]

    for row_idx, (left_text, right_text) in enumerate(sig_data):
        row = sig_table.rows[row_idx]
        cell_l = row.cells[0]
        cell_r = row.cells[1]
        cell_l.width = Inches(3.2)
        cell_r.width = Inches(3.2)
        
        p_l = cell_l.paragraphs[0]
        p_l.paragraph_format.line_spacing = 1.15
        p_l.paragraph_format.space_after = Pt(25)
        r = p_l.add_run(left_text)
        r.font.bold = True
        r.font.size = Pt(10)
        
        p_r = cell_r.paragraphs[0]
        p_r.paragraph_format.line_spacing = 1.15
        p_r.paragraph_format.space_after = Pt(25)
        p_r.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        r = p_r.add_run(right_text)
        r.font.bold = True
        r.font.size = Pt(10)

    p_ext = doc.add_paragraph()
    p_ext.paragraph_format.space_before = Pt(30)
    p_ext.alignment = WD_ALIGN_PARAGRAPH.CENTER
    r = p_ext.add_run("(Sign of External Examiner)")
    r.font.bold = True
    r.font.size = Pt(10)

    doc.add_page_break()

    # ================= 3. CONDUCTS OF THE INTERNSHIP TRAINING =================
    style_heading(doc, "CONDUCTS OF THE INTERNSHIP TRAINING", size=Pt(13), color=RGBColor(2, 132, 199))
    
    t_conducts = doc.add_table(rows=8, cols=2)
    t_conducts.style = 'Table Grid'
    t_conducts.alignment = WD_TABLE_ALIGNMENT.CENTER

    conducts_data = [
        ("Category", "Details"),
        ("Place of Internship", "Codec Technologies India, Powai, Mumbai, Maharashtra (Hybrid/Online Platform)"),
        ("Industry Supervisor", "Ms. Vaishali Shrivastava (Industry Mentor)"),
        ("Department Supervisor", "Dr. Anurag Shrivastava (Program Manager)"),
        ("Faculty Mentor", "Prof. Vinay Hiwanj"),
        ("Internship Duration", "12/01/2026 to 12/02/2026 (4 Weeks)"),
        ("Total Working Hours", "160 Hours (Estimated)"),
        ("Overall Attendance", "93%")
    ]

    for r_idx, (k, v) in enumerate(conducts_data):
        row = t_conducts.rows[r_idx]
        c0, c1 = row.cells[0], row.cells[1]
        c0.width = Inches(2.3)
        c1.width = Inches(4.2)
        c0.text = k
        c1.text = v
        set_cell_margins(c0, 70, 70, 100, 100)
        set_cell_margins(c1, 70, 70, 100, 100)
        if r_idx == 0:
            set_cell_background(c0, "0284C7")
            set_cell_background(c1, "0284C7")
            c0.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
            c0.paragraphs[0].runs[0].font.bold = True
            c1.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
            c1.paragraphs[0].runs[0].font.bold = True
        else:
            c0.paragraphs[0].runs[0].font.bold = True

    doc.add_page_break()

    # ================= 4. COLLEGE PERMISSION & OFFER LETTER PLACEHOLDERS =================
    style_heading(doc, "COLLEGE PERMISSION LETTER", size=Pt(13), color=RGBColor(2, 132, 199))
    add_p(doc, "[Official College Permission Letter issued by Dr. D. Y. Patil Technical Campus, Talegaon, approving the hybrid internship program for academic session 2025-26 under Savitribai Phule Pune University.]", space_after=Pt(30))

    style_heading(doc, "COMPANY OFFER LETTER", size=Pt(13), color=RGBColor(2, 132, 199))
    add_p(doc, "[Official Internship Offer Letter issued by Codec Technologies India, Powai, Mumbai, signed by Program Manager Dr. Anurag Shrivastava, confirming placement as AI & Data Analytics Intern for 160 hours.]", space_after=Pt(30))

    doc.add_page_break()

    # ================= 5. ACKNOWLEDGEMENT =================
    style_heading(doc, "ACKNOWLEDGEMENT", size=Pt(13), color=RGBColor(2, 132, 199))
    ack_text = (
        "With due respect and gratitude I take the opportunity to thank those who have helped me directly and indirectly. "
        "I convey my sincere thanks to Dr. Sandip A. Kahate, HoD, Computer Science Dept. for giving the permission for the "
        "internship and thanks to internal guide/ mentor Prof. Vinay Hiwanj for their help during the internship and support.\n\n"
        "I am especially grateful to my internship coordinator Prof. Swapnil More for timely post all the internship opportunities "
        "and his help and valuable suggestions in internship. Attempts have been made to minimize the errors in the report.\n\n"
        "I am highly indebted to Codec Technologies India Team for their guidance and constant supervision as well as for providing "
        "necessary information regarding the project and also for their support in completing the project.\n\n"
        "I would like to express my special gratitude and thanks to Ms. Vaishali Shrivastava for giving me such attention and time.\n\n"
        "I am thankful to the staff of Computer Science Department for their cooperation and support.\n\n"
        "I would also like to express my appreciation and thanks to all my friends who knowingly or unknowingly have assisted and encourage me throughout my hard work.\n\n"
        "Finally how can I forget the almighty the supreme power the GOD and my loving parents without which this work task was a distant dream?\n"
    )
    add_p(doc, ack_text, space_after=Pt(12))

    p_sig = doc.add_paragraph()
    p_sig.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    r = p_sig.add_run("Tanvi Sagar Unde\n(TE Computer Science, Roll No: 32170)")
    r.font.bold = True

    doc.add_page_break()

    # ================= 6. ABSTRACT =================
    style_heading(doc, "ABSTRACT", size=Pt(13), color=RGBColor(2, 132, 199))
    abstract_text = (
        "This report outlines a one-month professional internship at Codec Technologies India focused on Artificial Intelligence and "
        "Knowledge Engineering. The project addressed critical clinical decision support challenges by developing an explainable "
        "Rule-Based Expert System for Medical Diagnosis using Forward and Backward Chaining inference mechanisms.\n\n"
        "Unlike opaque machine learning models, the medical diagnosis system was engineered to deliver deterministic, fully auditable "
        "clinical reasoning. The system integrates a Knowledge Base of 24 clinical symptoms across anatomical categories, 12 target "
        "pathologies (including COVID-19, Malaria, Influenza, Typhoid, Strep Throat, Common Cold, and Dengue), and 12 production rules "
        "(IF-THEN format). Forward Chaining is used for data-driven bottom-up screening, while Backward Chaining performs goal-driven "
        "top-down hypothesis testing through an interactive patient dialogue. The internship demonstrated the practical application "
        "of symbolic AI to solve real-world healthcare triage challenges, resulting in a Grade A performance evaluation."
    )
    add_p(doc, abstract_text, space_after=Pt(15))

    # ================= 7. LIST OF CONTENTS =================
    style_heading(doc, "Contents", size=Pt(13), color=RGBColor(2, 132, 199))

    toc_entries = [
        ("Contents", "Page No"),
        ("Title Page", "01"),
        ("Conducts of the Internship Training", "02"),
        ("College permission letter", "03"),
        ("Company Offer letter", "04"),
        ("Certificate of Internship", "05"),
        ("Acknowledgement", "06"),
        ("Abstract", "07"),
        ("List of Contents", "08"),
        ("Weekly Overview of internship activity", "09"),
        ("Background of the Company", "10"),
        ("Structure of the Company", "11"),
        ("How Obtained this Training Opportunity", "12"),
        ("Knowledge and Skills Acquired", "13"),
        ("Details of Work Accomplished (Introduction, Module Description, System Analysis, System Architecture, SRS, Technology, Screen Shots)", "14"),
        ("Internship Placement Experiences", "16"),
        ("Challenges, Issues and Constraints", "17"),
        ("SWOT (strengths, weaknesses, opportunities, and threats) Analysis", "19"),
        ("Recommendations for Future Efforts", "20"),
        ("Conclusion", "22")
    ]

    t_toc = doc.add_table(rows=len(toc_entries), cols=2)
    t_toc.style = 'Table Grid'
    t_toc.alignment = WD_TABLE_ALIGNMENT.CENTER

    for r_idx, (c_name, p_num) in enumerate(toc_entries):
        row = t_toc.rows[r_idx]
        c0, c1 = row.cells[0], row.cells[1]
        c0.width = Inches(5.3)
        c1.width = Inches(1.2)
        c0.text = c_name
        c1.text = p_num
        set_cell_margins(c0, 50, 50, 80, 80)
        set_cell_margins(c1, 50, 50, 80, 80)
        if r_idx == 0:
            set_cell_background(c0, "0284C7")
            set_cell_background(c1, "0284C7")
            c0.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
            c0.paragraphs[0].runs[0].font.bold = True
            c1.paragraphs[0].runs[0].font.color.rgb = RGBColor(255, 255, 255)
            c1.paragraphs[0].runs[0].font.bold = True
            c1.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER
        else:
            c1.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

    doc.add_page_break()

    # ================= 8. WEEKLY OVERVIEW OF INTERNSHIP ACTIVITIES =================
    style_heading(doc, "WEEKLY OVERVIEW OF INTERNSHIP ACTIVITIES", size=Pt(13), color=RGBColor(2, 132, 199))

    weeks = [
        ("1st WEEK", [
            ("12/01/26", "Monday", "Introduction to Project Scope, Expert Systems, and AI Clinical Roadmap"),
            ("13/01/26", "Tuesday", "Python Environment Setup, Dependency Management, and Directory Structure"),
            ("14/01/26", "Wednesday", "Understanding Knowledge Representation and Data Types in Symbolic AI"),
            ("15/01/26", "Thursday", "Domain Knowledge Acquisition: Cataloging 24 Clinical Symptoms and 12 Diseases"),
            ("16/01/26", "Friday", "Rule Formulation: Drafting Production Rules (Antecedents & Consequents)"),
            ("17/01/26", "Saturday", "Review of fundamental AI Reasoning: Forward Chaining vs Backward Chaining")
        ]),
        ("2nd WEEK", [
            ("19/01/26", "Monday", "Literature Survey: Researching Historical Expert Systems (MYCIN, CASNET, EMYCIN)"),
            ("20/01/26", "Tuesday", "Literature Survey: Clinical Decision Support Metrics and Benchmark Practices"),
            ("21/01/26", "Wednesday", "Knowledge Engineering: Structuring Symptoms and Disease Profiles in Python"),
            ("22/01/26", "Thursday", "Developing Working Memory for Dynamic Fact Assertion and State Retention"),
            ("23/01/26", "Friday", "Implementing the Forward Chaining Engine (Data-Driven Pattern Matching Loop)"),
            ("24/01/26", "Saturday", "Weekly review of forward chaining deductions and multi-step inference tests")
        ]),
        ("3rd WEEK", [
            ("26/01/26", "Monday", "Modulation: Implementation of Intermediate Fact Derivations (e.g. Systemic Infection)"),
            ("27/01/26", "Tuesday", "Modulation: Designing Recursive Backward Chaining (Goal-Driven Proof Engine)"),
            ("28/01/26", "Wednesday", "Prototyping: Interactive Inquiry Engine with Dynamic Patient Callback"),
            ("29/01/26", "Thursday", "Prototyping: Building Explanation Facility with Step-by-Step Audit Traces"),
            ("30/01/26", "Friday", "Developing the first iteration of the Command Line Interface (CLI)"),
            ("31/01/26", "Saturday", "Finalizing the project modules and prototype Flask web architecture")
        ]),
        ("4th WEEK", [
            ("02/02/26", "Monday", "Implementing the Web Dashboard and Standalone Interactive Frontend UI"),
            ("03/02/26", "Tuesday", "Testing model performance across positive, negative, and edge test cases"),
            ("04/02/26", "Wednesday", "Evaluating Accuracy, Differential Match Percentages, and Cycle Efficiency"),
            ("05/02/26", "Thursday", "Generating visualization diagrams for system architecture and chaining flowcharts"),
            ("06/02/26", "Friday", "Performance Analysis: Benchmarking Forward vs Backward Chaining response times"),
            ("07/02/26", "Saturday", "Final project session: Finalizing results, presentation, and documentation")
        ])
    ]

    for w_name, d_list in weeks:
        p_w = doc.add_paragraph()
        p_w.paragraph_format.space_before = Pt(8)
        p_w.paragraph_format.space_after = Pt(3)
        r = p_w.add_run(f"★ {w_name}")
        r.font.bold = True
        r.font.color.rgb = RGBColor(2, 132, 199)

        t = doc.add_table(rows=len(d_list) + 1, cols=3)
        t.style = 'Table Grid'
        t.alignment = WD_TABLE_ALIGNMENT.CENTER
        t.rows[0].cells[0].text = "DATE"
        t.rows[0].cells[1].text = "DAY"
        t.rows[0].cells[2].text = "NAME OF THE TOPIC/MODULE COMPLETED"
        t.rows[0].cells[0].width = Inches(1.1)
        t.rows[0].cells[1].width = Inches(1.2)
        t.rows[0].cells[2].width = Inches(4.2)
        for c in range(3):
            set_cell_background(t.rows[0].cells[c], "F1F5F9")
            t.rows[0].cells[c].paragraphs[0].runs[0].font.bold = True
            set_cell_margins(t.rows[0].cells[c], 40, 40, 70, 70)

        for idx, (dt, dy, top) in enumerate(d_list, 1):
            row = t.rows[idx]
            row.cells[0].text = dt
            row.cells[1].text = dy
            row.cells[2].text = top
            for c in range(3):
                set_cell_margins(row.cells[c], 40, 40, 70, 70)

    doc.add_page_break()

    # ================= 9. BACKGROUND OF THE COMPANY =================
    style_heading(doc, "BACKGROUND OF THE COMPANY", size=Pt(13), color=RGBColor(2, 132, 199))
    
    add_p(doc, 
          "Codec Technologies India is a premier global platform dedicated to IT and business consultancy services. "
          "With a mission to empower learners and connect diverse talent, the organization provides innovative solutions "
          "that drive meaningful career opportunities and strategic growth worldwide.\n\n"
          "1. Global Presence & Operations: The company operates extensively across more than 27 countries, maintaining "
          "a global delivery model that leverages diverse talent pools. Its headquarters for Indian operations is located in Powai, "
          "Mumbai, Maharashtra, which serves as a hub for its consultancy and project management services.\n\n"
          "2. Core Services & Domain Expertise: Codec Technologies specializes in several key domains within the technology sector, "
          "including Data Analytics & Machine Learning, Artificial Intelligence & Expert Systems, Healthcare Decision Support, and "
          "Skill Development & Training offering AICTE-approved professional training programs.\n\n"
          "3. Accreditation & Quality Standards: The company is an ISO 9001:2015 Certified organization, ensuring that its internal "
          "processes and project delivery mechanisms meet international quality management standards. Furthermore, it is a recognized "
          "Google for Education Partner.\n\n"
          "4. Industry Recognition: Through partnerships with the Ministry of Education’s National Internship Portal (AICTE), Codec "
          "Technologies provides students with immersive, industry-level experiences recognized by the International Certification "
          "Accreditation Council (ICAC).\n\n"
          "5. Leadership and Vision: Under the leadership of program managers like Dr. Anurag Shrivastava, the company fosters a "
          "culture of professionalism, initiative, and outstanding problem-solving."
    )

    # ================= 10. STRUCTURE OF THE COMPANY =================
    style_heading(doc, "STRUCTURE OF COMPANY", size=Pt(13), color=RGBColor(2, 132, 199))
    
    add_p(doc,
          "Codec Technologies India operates with a well-defined corporate hierarchy and a global delivery model designed to support "
          "its IT consultancy and AI development services.\n\n"
          "1. Organizational Hierarchy: The company follows a professional management structure that ensures every project is overseen "
          "by domain experts while allowing trainees direct mentorship. Executive Management sets strategic vision; Program/Operations "
          "Management (Dr. Anurag Shrivastava) oversees compliance; Industry Mentors (Ms. Vaishali Shrivastava) guide day-to-day sprints; "
          "and the Project Internship Division accommodates student engineering interns.\n\n"
          "2. Departmental Segregation: The organization comprises specialized departments: Data Science & AI Department (where this "
          "expert system project was developed), Healthcare Analytics Division, Business Consultancy, Talent Acquisition, and Quality Assurance.\n\n"
          "3. Work Culture and Communication: Operates under a Hybrid Structure blending physical oversight with online collaborative tools, "
          "using weekly agile sprints, project portals, and professional email support (support@codectechnologies.in)."
    )

    # ================= 11. HOW OBTAINED THIS TRAINING OPPORTUNITY =================
    style_heading(doc, "HOW OBTAINED THIS TRAINING OPPORTUNITY", size=Pt(13), color=RGBColor(2, 132, 199))

    add_p(doc,
          "The opportunity to intern at Codec Technologies India was secured through a competitive and formal application process "
          "facilitated by the Ministry of Education’s National Internship Portal (AICTE).\n\n"
          "1. Discovery and Application: The process began by identifying the AI and Data Science internship listing on the AICTE Portal. "
          "After reviewing the prerequisites—emphasizing Computer Science principles and automated decision-making—I submitted credentials "
          "and academic profile.\n\n"
          "2. Selection Process: Applications underwent initial screening based on academic record, followed by technical evaluations in "
          "Python programming and algorithmic reasoning. Upon successful evaluation, an official Offer Letter was issued by Dr. Anurag Shrivastava.\n\n"
          "3. Formal Onboarding: Onboarding occurred via Codec Technologies' digital portal, including assignment of Industry Mentor Ms. Vaishali "
          "Shrivastava and scheduling of Monthly Progress Reports (MPR).\n\n"
          "4. Academic Alignment: This internship fulfilled requirements for Third Year Engineering (Course Code: 310255) under Savitribai "
          "Phule Pune University, approved by HoD Dr. Sandip A. Kahate."
    )

    doc.add_page_break()

    # ================= 12. KNOWLEDGE AND SKILLS ACQUIRED =================
    style_heading(doc, "KNOWLEDGE AND SKILLS ACQUIRED", size=Pt(13), color=RGBColor(2, 132, 199))

    add_p(doc,
          "The internship provided an intensive learning environment bridging theoretical computer science with production-grade AI.\n\n"
          "1. Technical Skills in AI & Expert Systems:\n"
          "• Knowledge Representation: Mastered encoding medical taxonomy into production rules (IF-THEN statements).\n"
          "• Forward Chaining: Implemented data-driven bottom-up pattern matching loops with conflict resolution.\n"
          "• Backward Chaining: Engineered goal-driven recursive resolution algorithms with interactive patient query callbacks.\n"
          "• Full-Stack Python: Built modular systems using Python 3.13, Flask 3.1.2 REST APIs, and responsive HTML/CSS/JavaScript.\n\n"
          "2. Machine Learning & Statistical Analysis:\n"
          "• Learned to evaluate categorical medical data, set differential match scores, and handle incomplete symptom matrices.\n"
          "• Constructed explanation facilities to convert internal rule firings into transparent clinical audit traces.\n\n"
          "3. Professional & Soft Skills:\n"
          "• Agile Sprint Management: Delivered weekly sprint milestones on schedule.\n"
          "• Corporate Communication: Maintained reporting with mentor Ms. Vaishali Shrivastava.\n"
          "• High Discipline: Maintained 93% attendance and received a Grade A performance evaluation."
    )

    # ================= 13. DETAILS OF WORK ACCOMPLISHED =================
    style_heading(doc, "DETAILS OF WORK ACCOMPLISHED", size=Pt(13), color=RGBColor(2, 132, 199))

    add_p(doc,
          "The project developed during the internship is titled 'AI Medical Diagnosis System (Rule-Based Expert System using Forward "
          "and Backward Chaining)'. The primary objective was to build a deterministic, explainable clinical decision support tool.\n\n"
          "1. Introduction: Medical diagnosis requires high transparency and safety. The system models a physician's deductive reasoning "
          "to triage diseases from symptoms using formal production rules.\n\n"
          "2. Module Description:\n"
          "• Module 1: Knowledge Base (knowledge_base.py) - Encodes 24 symptoms, 12 disease profiles, and 12 production rules.\n"
          "• Module 2: Forward Chaining Engine (inference_engine.py) - Aggregates symptoms, fires rules, and returns diagnoses & match scores.\n"
          "• Module 3: Backward Chaining Engine (inference_engine.py) - Evaluates a disease hypothesis through recursive interactive inquiries.\n"
          "• Module 4: User Interface & Explanation Facility - Interactive CLI (cli_diagnosis.py), Web Dashboard (app.py), and Standalone App (Medical_Diagnosis_System_App.html).\n\n"
          "3. System Analysis: Analyzed symptom co-occurrence patterns across respiratory, systemic, and gastrointestinal conditions. "
          "Formulated conflict resolution strategies: rules fire in prioritized sweeps until reaching quiescent state.\n\n"
          "4. System Architecture: Operates on a classic 4-layer pipeline: Presentation Layer (Web/CLI) <-> Inference Layer (FC/BC Engines) "
          "<-> Working Memory (Blackboard) <-> Knowledge Base (Rules & Metadata) -> Explanation Facility.\n\n"
          "5. SRS (Software Requirements Specification):\n"
          "• Operating System: Windows 10/11 or Linux.\n"
          "• Language: Python 3.8+ (Tested on Python 3.13).\n"
          "• Framework: Flask 3.1.2 (for web server), HTML5/CSS3/ES6 (frontend).\n"
          "• Hardware: Dual-Core 2.0 GHz CPU, 2 GB RAM, 100 MB disk space.\n\n"
          "6. Technology: Pure Python data structures (sets, dictionaries) for O(1) antecedent matching, Flask REST APIs, and JSON serialization.\n\n"
          "7. Screen Shots / Sample Test Runs:\n"
          "• Test Run 1 (Forward Chaining - COVID-19): Input [fever, cough, fatigue, loss_of_taste_smell] -> Rule R_COVID fires -> Diagnosis: COVID-19 confirmed.\n"
          "• Test Run 2 (Backward Chaining - Malaria): Goal 'Malaria' -> System asks for high_fever, chills, sweating, headache -> Patient answers YES -> Hypothesis Confirmed."
    )

    # Embed diagrams
    if os.path.exists("diagrams/system_architecture.png"):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p_img.add_run()
        run.add_picture("diagrams/system_architecture.png", width=Inches(5.8))
        p_c = doc.add_paragraph()
        p_c.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p_c.add_run("Figure 1: Medical Diagnosis Expert System Architecture Pipeline")
        r.font.italic = True
        r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor(100, 116, 139)

    if os.path.exists("diagrams/flowchart_chaining.png"):
        p_img = doc.add_paragraph()
        p_img.alignment = WD_ALIGN_PARAGRAPH.CENTER
        run = p_img.add_run()
        run.add_picture("diagrams/flowchart_chaining.png", width=Inches(5.8))
        p_c = doc.add_paragraph()
        p_c.alignment = WD_ALIGN_PARAGRAPH.CENTER
        r = p_c.add_run("Figure 2: Forward vs. Backward Chaining Algorithmic Flowchart")
        r.font.italic = True
        r.font.size = Pt(9.5)
        r.font.color.rgb = RGBColor(100, 116, 139)

    doc.add_page_break()

    # ================= 14. INTERNSHIP PLACEMENT EXPERIENCES =================
    style_heading(doc, "INTERNSHIP PLACEMENT EXPERIENCES", size=Pt(13), color=RGBColor(2, 132, 199))

    add_p(doc,
          "The internship placement at Codec Technologies provided a transformative experience, offering a realistic view of the "
          "professional IT consultancy landscape. This period served as a critical bridge between theoretical classroom learning "
          "at Savitribai Phule Pune University and practical demands of the global industry.\n\n"
          "1. Transition to a Professional Environment: Entering a Hybrid/Online professional setup required a significant shift in "
          "mindset. I learned to manage my own schedule to meet the 160-hour requirement, emphasizing self-discipline and result-oriented "
          "work. This experience highlighted the importance of a professional workspace and corporate tools.\n\n"
          "2. Industry Mentorship and Growth: Working under the guidance of Ms. Vaishali Shrivastava and Dr. Anurag Shrivastava provided "
          "invaluable insights into industry standards. The Monthly Progress Report (MPR) system acted as a vital feedback mechanism, "
          "evaluating work on criteria like punctuality, quality, and sincerity.\n\n"
          "3. Application of Agile Methodology: The placement introduced me to the Agile framework. By breaking down the internship into "
          "weekly sprints—from Literature Surveys to Prototyping and Testing—I gained experience in systematic project delivery.\n\n"
          "4. Technical Confidence and Problem Solving: Implementing both forward and backward chaining from scratch taught me that real-world "
          "AI engineering is as much about persistence and edge-case handling as it is about coding.\n\n"
          "5. Final Reflection: Achieving Grade A and receiving a Letter of Recommendation are testaments to the growth I experienced. "
          "I gained not only technical proficiency in AI Expert Systems but also behavioral discipline essential for an engineering career."
    )

    # ================= 15. CHALLENGES, ISSUES AND CONSTRAINTS =================
    style_heading(doc, "CHALLENGES, ISSUES AND CONSTRAINTS", size=Pt(13), color=RGBColor(2, 132, 199))

    add_p(doc,
          "During the development of the Medical Diagnosis Expert System, several technical and operational challenges were encountered.\n\n"
          "1. Knowledge Base Quality & Rules Definition: Distilling clinical knowledge into crisp IF-THEN rules presented the classic "
          "'knowledge acquisition bottleneck'. Ensuring that rules did not conflict or produce false positives required precise selection "
          "of distinguishing symptoms.\n\n"
          "2. Technical Constraints in Inference Algorithms: Real-world patients often present incomplete symptoms. Strict rule satisfaction "
          "would fail to diagnose. To solve this constraint, a differential scoring metric was engineered to calculate match percentages.\n\n"
          "3. Operational and Environmental Constraints: Coordinating with mentor Ms. Vaishali Shrivastava in a hybrid environment "
          "demanded strict self-discipline and digital time management to complete all 4 weekly sprints within 160 hours.\n\n"
          "4. Analytical Challenges: Recursive backward chaining posed risks of circular loops if rules cross-referenced. A visited-goals "
          "set was designed to prune circular branches dynamically."
    )

    # ================= 16. SWOT ANALYSIS =================
    style_heading(doc, "SWOT ANALYSIS", size=Pt(13), color=RGBColor(2, 132, 199))

    add_p(doc,
          "1. Strengths (Internal):\n"
          "• Complete Explainability: 100% deterministic reasoning with human-readable audit traces.\n"
          "• Dual Reasoning Paradigms: Implements both Forward and Backward chaining seamlessly.\n"
          "• Zero Dependency on Heavy Libraries: Highly portable and fast (<10ms execution time).\n"
          "• Multi-Interface Support: Terminal CLI, Flask Web Server, and Standalone Zero-Setup App.\n\n"
          "2. Weaknesses (Internal):\n"
          "• Crisp Logic Constraint: Uses Boolean True/False values rather than probabilistic certainty factors.\n"
          "• Static Rule Base: Adding new pathologies requires manual rule specification rather than automated learning.\n\n"
          "3. Opportunities (External):\n"
          "• Electronic Health Records: Integrating with hospital systems via FHIR APIs.\n"
          "• Mobile App Deployment: Building offline apps for rural community health clinics.\n"
          "• Hybrid AI: Combining rule-based safety guardrails with machine learning classifiers.\n\n"
          "4. Threats (External):\n"
          "• Clinical Liability: Must remain a decision support tool and never replace certified medical doctors.\n"
          "• Rapidly Evolving Medical Protocols: Requires ongoing updates as clinical guidelines change."
    )

    doc.add_page_break()

    # ================= 17. RECOMMENDATIONS FOR FUTURE EFFORTS =================
    style_heading(doc, "RECOMMENDATIONS FOR FUTURE", size=Pt(13), color=RGBColor(2, 132, 199))

    add_p(doc,
          "1. Advanced Reasoning with Certainty Factors & Fuzzy Logic:\n"
          "Future versions should incorporate MYCIN-style Certainty Factors (-1.0 to +1.0) and fuzzy logic membership functions "
          "to model subjective symptoms like 'mild fever' or 'occasional cough'.\n\n"
          "2. Real-Time Healthcare Data Integration:\n"
          "Transitioning from manual checkbox entry toward live ingestion from wearable sensors (measuring SpO2, heart rate, temperature) "
          "into working memory automatically.\n\n"
          "3. Mobile and Offline Clinical Deployment:\n"
          "Developing cross-platform mobile apps (Flutter / React Native) that allow health workers in rural villages to run diagnostic "
          "triage without requiring internet connectivity.\n\n"
          "4. Deepening Data Preprocessing & Multi-Modal Fusion:\n"
          "Combining symbolic rule-based diagnosis with computer vision models capable of analyzing chest X-rays or skin rash images.\n\n"
          "5. Production Deployment and Clinical MLOps:\n"
          "Deploying the reasoning engine on secure cloud platforms (AWS / GCP) with automated rule validation and version control."
    )

    # ================= 18. CONCLUSION =================
    style_heading(doc, "CONCLUSION", size=Pt(13), color=RGBColor(2, 132, 199))

    add_p(doc,
          "The one-month internship at Codec Technologies India has been a significant milestone in my academic and professional "
          "development as a Computer Science student under Savitribai Phule Pune University.\n\n"
          "1. Achievement of Project Objectives: The primary technical goal—building a functional, explainable Medical Diagnosis Expert "
          "System using Forward and Backward Chaining—was successfully accomplished. The system provides clear diagnostic recommendations, "
          "precautions, and step-by-step reasoning traces.\n\n"
          "2. Technical Growth: Gained mastery of symbolic AI, knowledge engineering, full-stack Python development, and automated test-driven "
          "verification, achieving 100% unit test pass rates.\n\n"
          "3. Professional and Behavioral Development: Maintaining a 93% attendance rate and receiving a Grade A reflects my commitment "
          "to professional discipline and the Agile weekly sprint methodology.\n\n"
          "4. Future Outlook: The Letter of Recommendation and ICAC-approved certification have provided a solid foundation for future "
          "pursuits in Artificial Intelligence and Healthcare Technology.\n\n"
          "In finality, I express my sincere gratitude to the Department of Computer Science at Dr. D.Y. Patil Technical Campus and the "
          "mentors at Codec Technologies India for this invaluable opportunity."
    )

    output_path = "Medical_Diagnosis_System_Report.docx"
    doc.save(output_path)
    print(f"Report successfully saved at: {output_path}")

if __name__ == "__main__":
    generate_report()
