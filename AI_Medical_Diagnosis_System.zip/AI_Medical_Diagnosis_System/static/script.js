// JavaScript for Medical Diagnosis Expert System

let appData = {
    symptoms: {},
    diseases: {},
    rules: []
};

// Backward chaining interactive state
let bcState = {
    active: false,
    goal: null,
    requiredSymptoms: [],
    currentIndex: 0,
    answers: {}
};

document.addEventListener("DOMContentLoaded", async () => {
    // 1. Initialize Tabs
    setupTabs();

    // 2. Load Knowledge Data from API
    await loadAppData();

    // 3. Setup Checkbox listeners
    setupCheckboxListeners();
});

function setupTabs() {
    const tabButtons = document.querySelectorAll(".tab-btn");
    const tabContents = document.querySelectorAll(".tab-content");

    tabButtons.forEach(btn => {
        btn.addEventListener("click", () => {
            const targetId = btn.getAttribute("data-tab");

            tabButtons.forEach(b => b.classList.remove("active"));
            tabContents.forEach(c => c.classList.remove("active"));

            btn.classList.add("active");
            const targetEl = document.getElementById(targetId);
            if (targetEl) targetEl.classList.add("active");
        });
    });
}

async function loadAppData() {
    try {
        const res = await fetch("/api/data");
        const data = await res.json();
        appData = data;
    } catch (e) {
        console.error("Error loading app data:", e);
    }
}

function setupCheckboxListeners() {
    const checkboxes = document.querySelectorAll('input[name="symptom"]');
    checkboxes.forEach(cb => {
        cb.addEventListener("change", () => {
            const label = document.getElementById(`lbl-${cb.value}`);
            if (label) {
                if (cb.checked) {
                    label.classList.add("selected");
                } else {
                    label.classList.remove("selected");
                }
            }
            updateSymptomCounter();
        });
    });
}

function updateSymptomCounter() {
    const selected = document.querySelectorAll('input[name="symptom"]:checked');
    const counterEl = document.getElementById("selected-counter");
    if (counterEl) {
        counterEl.textContent = `${selected.length} symptom${selected.length === 1 ? '' : 's'} selected`;
    }
}

function clearSymptoms() {
    const checkboxes = document.querySelectorAll('input[name="symptom"]');
    checkboxes.forEach(cb => {
        cb.checked = false;
        const label = document.getElementById(`lbl-${cb.value}`);
        if (label) label.classList.remove("selected");
    });
    updateSymptomCounter();
}

function applyPreset(presetType) {
    clearSymptoms();
    const presets = {
        covid: ["fever", "cough", "fatigue", "loss_of_taste_smell"],
        malaria: ["high_fever", "chills", "sweating", "headache"],
        cold: ["cough", "sore_throat", "runny_nose", "sneezing"],
        allergy: ["sneezing", "runny_nose", "itchy_eyes"]
    };

    const targetList = presets[presetType] || [];
    targetList.forEach(s => {
        const cb = document.querySelector(`input[name="symptom"][value="${s}"]`);
        if (cb) {
            cb.checked = true;
            const label = document.getElementById(`lbl-${s}`);
            if (label) label.classList.add("selected");
        }
    });
    updateSymptomCounter();
}

/* ================= FORWARD CHAINING ================= */

async function runForwardChaining() {
    const selectedCheckboxes = document.querySelectorAll('input[name="symptom"]:checked');
    const selectedSymptoms = Array.from(selectedCheckboxes).map(cb => cb.value);

    if (selectedSymptoms.length === 0) {
        alert("Please select at least one symptom before running diagnosis.");
        return;
    }

    try {
        const res = await fetch("/api/forward_chain", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({ symptoms: selectedSymptoms })
        });
        const data = await res.json();

        displayForwardResults(data);
    } catch (e) {
        console.error("Diagnosis error:", e);
        alert("An error occurred while running forward chaining.");
    }
}

function displayForwardResults(data) {
    document.getElementById("forward-empty-state").style.display = "none";
    const wrapper = document.getElementById("forward-results-wrapper");
    wrapper.style.display = "block";

    // 1. Render Diagnoses
    const diagContainer = document.getElementById("diagnosis-cards-container");
    diagContainer.innerHTML = "";

    if (data.diagnoses.length > 0) {
        data.diagnoses.forEach(diag => {
            const card = document.createElement("div");
            card.className = "diag-card";

            const precautionsHtml = diag.precautions.map(p => `<li>${p}</li>`).join("");

            card.innerHTML = `
                <div class="diag-header">
                    <h3 class="diag-title">★ Confirmed: ${diag.title}</h3>
                    <span class="badge-severity ${diag.severity.toLowerCase()}">${diag.severity}</span>
                </div>
                <p style="font-size: 0.88rem; margin-bottom: 8px;">${diag.description}</p>
                <div class="diag-doctor">🩺 Recommended Specialist: <strong>${diag.doctor}</strong></div>
                <div class="precautions-box">
                    <h5>Recommended Clinical Care & Precautions:</h5>
                    <ul>${precautionsHtml}</ul>
                </div>
            `;
            diagContainer.appendChild(card);
        });
    } else {
        diagContainer.innerHTML = `
            <div class="status-banner" style="background:#fef3c7; color:#92400e; border:1px solid #fde68a;">
                ℹ No single rule fully matched all symptoms for a 100% conclusive diagnosis. 
                Please inspect the partial matching scores below for probable conditions.
            </div>
        `;
    }

    // 2. Render Derived Facts
    const pillsContainer = document.getElementById("derived-facts-pills");
    pillsContainer.innerHTML = "";
    data.derived_facts.forEach(f => {
        const pill = document.createElement("span");
        pill.className = "fact-pill";
        const symName = appData.symptoms[f]?.name || f;
        pill.textContent = symName;
        pillsContainer.appendChild(pill);
    });

    // 3. Render Partial Matches
    const partialList = document.getElementById("partial-matches-list");
    partialList.innerHTML = "";
    data.partial_matches.slice(0, 5).forEach(pm => {
        const item = document.createElement("div");
        item.className = "progress-item";

        const isFull = pm.fully_matched;
        const missingNames = pm.missing_symptoms.map(s => appData.symptoms[s]?.name || s).join(", ");

        item.innerHTML = `
            <div class="progress-info">
                <span><strong>${pm.disease}</strong></span>
                <span>${pm.match_score}% Match ${isFull ? '✓' : ''}</span>
            </div>
            <div class="progress-bar-bg">
                <div class="progress-bar-fill ${isFull ? 'complete' : ''}" style="width: ${pm.match_score}%"></div>
            </div>
            ${pm.missing_symptoms.length > 0 ? `<div class="missing-tags">Missing to confirm: ${missingNames}</div>` : ''}
        `;
        partialList.appendChild(item);
    });

    // 4. Render Execution Trace
    const traceEl = document.getElementById("forward-trace");
    traceEl.textContent = data.trace.join("\n");
}

function toggleTrace(elementId) {
    const el = document.getElementById(elementId);
    if (el) {
        el.style.display = el.style.display === "none" ? "block" : "none";
    }
}

/* ================= BACKWARD CHAINING ================= */

function onGoalSelected() {
    const select = document.getElementById("goal-select");
    const val = select.value;
    const callout = document.getElementById("goal-info-box");

    if (val && appData.diseases[val]) {
        const info = appData.diseases[val];
        document.getElementById("callout-goal-name").textContent = info.name;
        document.getElementById("callout-goal-desc").textContent = info.description + " [Specialist: " + info.doctor + "]";
        callout.style.display = "block";
    } else {
        callout.style.display = "none";
    }

    // Reset interactive card
    document.getElementById("interactive-query-card").style.display = "none";
}

function startBackwardInteractive() {
    const select = document.getElementById("goal-select");
    const goal = select.value;

    if (!goal) {
        alert("Please select a disease hypothesis from the dropdown.");
        return;
    }

    // Find rules that conclude this disease to collect required symptoms
    const targetRules = appData.rules.filter(r => r.then_conclusion === goal);
    if (targetRules.length === 0) {
        alert(`No rules found for disease hypothesis: ${goal}`);
        return;
    }

    // Collect all unique symptoms from candidate rules
    const symptomsSet = new Set();
    targetRules.forEach(r => {
        r.if_conditions.forEach(c => symptomsSet.add(c));
    });

    bcState = {
        active: true,
        goal: goal,
        requiredSymptoms: Array.from(symptomsSet),
        currentIndex: 0,
        answers: {}
    };

    // Show questionnaire card
    document.getElementById("interactive-query-card").style.display = "block";
    showCurrentQuestion();
}

function showCurrentQuestion() {
    if (bcState.currentIndex >= bcState.requiredSymptoms.length) {
        // Finished asking all questions! Run backward chaining verification!
        finishBackwardInteractive();
        return;
    }

    const currentSymKey = bcState.requiredSymptoms[bcState.currentIndex];
    const symInfo = appData.symptoms[currentSymKey] || { name: currentSymKey };

    document.getElementById("question-progress").textContent = 
        `Condition ${bcState.currentIndex + 1} of ${bcState.requiredSymptoms.length}`;
    document.getElementById("current-question-text").textContent = 
        `Does the patient experience "${symInfo.name}"?`;
}

function answerQuestion(isYes) {
    const currentSymKey = bcState.requiredSymptoms[bcState.currentIndex];
    bcState.answers[currentSymKey] = isYes;
    bcState.currentIndex++;
    showCurrentQuestion();
}

async function finishBackwardInteractive() {
    document.getElementById("interactive-query-card").style.display = "none";

    try {
        const res = await fetch("/api/backward_chain", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                goal: bcState.goal,
                answers: bcState.answers
            })
        });

        const data = await res.json();
        displayBackwardResults(data);
    } catch (e) {
        console.error("Backward verification error:", e);
        alert("An error occurred during backward chaining verification.");
    }
}

function displayBackwardResults(data) {
    document.getElementById("backward-empty-state").style.display = "none";
    document.getElementById("backward-results-wrapper").style.display = "block";

    const banner = document.getElementById("backward-status-banner");
    const detailsContainer = document.getElementById("backward-disease-details");

    if (data.confirmed) {
        banner.className = "status-banner success";
        banner.innerHTML = `✓ <strong>HYPOTHESIS CONFIRMED:</strong> The patient's reported symptoms satisfy the production rules for <strong>${data.goal}</strong>.`;

        const dInfo = data.disease_info || {};
        const precautionsHtml = (dInfo.precautions || []).map(p => `<li>${p}</li>`).join("");

        detailsContainer.innerHTML = `
            <div class="diag-card">
                <div class="diag-header">
                    <h3 class="diag-title">${dInfo.name || data.goal}</h3>
                    <span class="badge-severity ${(dInfo.severity || 'moderate').toLowerCase()}">${dInfo.severity}</span>
                </div>
                <p style="font-size:0.88rem; margin-bottom:8px;">${dInfo.description || ''}</p>
                <div class="diag-doctor">🩺 Recommended Specialist: <strong>${dInfo.doctor || 'Physician'}</strong></div>
                <div class="precautions-box">
                    <h5>Recommended Clinical Care & Precautions:</h5>
                    <ul>${precautionsHtml}</ul>
                </div>
            </div>
        `;
    } else {
        banner.className = "status-banner danger";
        banner.innerHTML = `✗ <strong>HYPOTHESIS REFUTED:</strong> The patient's clinical conditions do NOT satisfy the rule requirements for <strong>${data.goal}</strong>.`;

        const missingNames = data.missing_symptoms.map(s => appData.symptoms[s]?.name || s).join(", ");
        detailsContainer.innerHTML = `
            <div class="status-banner" style="background:#fff1f2; color:#be123c; border:1px solid #fecdd3;">
                <p><strong>Unsatisfied Conditions / Absent Symptoms:</strong></p>
                <p style="margin-top:4px;">${missingNames || 'Key clinical antecedents were reported absent by user.'}</p>
            </div>
        `;
    }

    // Display Trace
    const traceEl = document.getElementById("backward-trace");
    traceEl.textContent = data.trace.join("\n");
}
